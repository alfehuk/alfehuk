import os, pygame, platform

pygame.font.init()

#GLOBAL VARIABLES
wakeWordDetected = False
prompt = ""
partialPrompt = ""
displayedPrompt = ""
steveReply = ""
wakeWord = "steve"
coverEars = False
updateAvailable = False
alarmDir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/alarms.json"
running = True
display = "Home"
alarmGoing = False
raspberryPi = platform.system() != "Darwin"
videoToPlay = False
conversation = None
inConvo = False

homeTransition = False
homeScreenOpac = 255