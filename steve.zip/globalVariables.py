import os, pygame, platform

pygame.font.init()

#GLOBAL VARIABLES
background = pygame.image.load(
os.path.dirname(os.path.abspath(__file__)) + "/background.jpg")
background = pygame.transform.scale(background, (1024, 600))
dateFont = pygame.font.Font(None, 50)
timeFont = pygame.font.Font(None, 80)
promptFont = pygame.font.Font(None, 45)
alarmFont = pygame.font.SysFont(None, 50)
wakeWordDetected = False
prompt = ""
partialPrompt = ""
steveReply = ""
wakeWord = "steve"
coverEars = False
updateAvailable = False
alarmDir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/alarms.json"
running = True
display = "Home"
alarmGoing = False
raspberryPi = platform.system() != "Darwin"