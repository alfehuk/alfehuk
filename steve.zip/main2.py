
from vosk import Model, KaldiRecognizer
import os
import platform
import queue
import time
import json
import threading
import sounddevice as sd

# Vosk setup
model = Model(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    + "/vosk-model-en-gb-0.1"
)
recognizer = KaldiRecognizer(model, 16000)

# Shared state
q = queue.Queue(maxsize=20)
partialPrompt = ""
prompt = ""


# Mac sounddevice callback
def callback(indata, frames, time_info, status):
    if status:
        print("Audio status:", status)

    try:
        q.put_nowait(bytes(indata))
    except queue.Full:
        # Drop an old block rather than letting the queue fall behind.
        try:
            q.get_nowait()
            q.put_nowait(bytes(indata))
        except queue.Empty:
            pass
        except queue.Full:
            pass


def process_audio(data):
    global prompt, partialPrompt, recognizer

    if recognizer.AcceptWaveform(data):
        result = json.loads(recognizer.Result())
        prompt = result.get("text", "")
        partialPrompt = ""
    else:
        result = json.loads(recognizer.PartialResult())
        partialPrompt = result.get("partial", "")


def listenForWakeWord():
    global recognizer

    while True:
        try:
            if platform.system() != "Darwin":
                # Raspberry Pi: ALSA handles sample-rate conversion.
                import alsaaudio

                mic = alsaaudio.PCM(
                    type=alsaaudio.PCM_CAPTURE,
                    mode=alsaaudio.PCM_NORMAL,
                    device="plughw:3,0"
                )

                mic.setchannels(1)
                mic.setrate(16000)
                mic.setformat(alsaaudio.PCM_FORMAT_S16_LE)

                # 1600 frames = 100 ms at 16 kHz.
                mic.setperiodsize(1600)

                print("Listening through ALSA at 16 kHz...")

                while True:
                    length, data = mic.read()

                    if length > 0:
                        process_audio(data)

            else:
                # Mac: keep using sounddevice.
                print("Listening through sounddevice at 16 kHz...")

                with sd.RawInputStream(
                    device=0,
                    samplerate=16000,
                    blocksize=4000,
                    dtype="int16",
                    channels=1,
                    callback=callback
                ):
                    while True:
                        data = q.get()
                        process_audio(data)

        except Exception as e:
            print("Audio stream error:", e)
            recognizer = KaldiRecognizer(model, 16000)
            time.sleep(1)


thread = threading.Thread(
    target=listenForWakeWord,
    daemon=True,
    name="Wake word checker"
)
thread.start()

while True:
    print(f"'{prompt}', '{partialPrompt}'")
    time.sleep(0.1)
