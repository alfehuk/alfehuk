import globalVariables, time, subprocess, json
from alarmHandling import alarmData, dumpAlarms, checkAlarms, addAlarm, alarmSound
from calendarHandling import getCalendar
from audioHandling import Say
from elevenlabs.conversational_ai.conversation import (Conversation,ConversationInitiationData)

def agentResponse(response):
    globalVariables.steveReply = response

def querySteve(query):
    conversation = Conversation(
        client=globalVariables.elevenlabs,
        agent_id=globalVariables.agentID,
        requires_auth=True,
        config=globalVariables.config,
        callback_agent_response=agentResponse
    )
    conversation.start_session()
    
    while True:
        try:
            conversation.send_user_message(query)
            break
        except RuntimeError as e:
            if "Session not started or websocket not connected" in str(e):
                time.sleep(0.1)
            else:
                raise
    safety = 0
    while globalVariables.steveReply == "...":
        safety += 1
        time.sleep(0.05)
        if safety > 400:
            break

    conversation.end_session()
    return globalVariables.steveReply

def reply(Question=None):
    globalVariables.steveReply = "..."

    globalVariables.coverEars = True
    if Question == None:
        rawPrompt = globalVariables.prompt[len(globalVariables.wakeWord)+1:]
    else:
        rawPrompt = Question
    sleeping = False
    sleepCommands = ["sleep", "turn off screen", "screen off", "turn screen off", "screen of", "turn screen of", "turn of screen"]
    
    if rawPrompt != "" and rawPrompt != "stop" and rawPrompt not in sleepCommands:
        querySteve(rawPrompt)

    elif rawPrompt in sleepCommands:
        globalVariables.steveReply = "Just remember to press the top button on the right side of me twice when you want me back, ok?"
        sleeping = True
    elif rawPrompt == "stop":
        globalVariables.steveReply = ""
        globalVariables.display = "Home"
        globalVariables.wakeWordDetected = False
        return
    else:
        globalVariables.steveReply = "Hi Lucca, how can I help?"

    settingAlarm = False
    checkingCalendar = False

    if '["Alarm"' in globalVariables.steveReply or '["Timer"' in globalVariables.steveReply:
        settingAlarm = True
        inp = globalVariables.steveReply.split(" [")
        globalVariables.steveReply = inp[0]

    elif '["Calendar"' in globalVariables.steveReply:
        checkingCalendar = globalVariables.steveReply
        globalVariables.steveReply = "Checking your calendar..."

    Say(globalVariables.steveReply)

    if settingAlarm:
        addAlarm(f"[{inp[1]}")

    if checkingCalendar != False:
        Calendar = getCalendar(checkingCalendar)
        reply(f"lucca is asking '{json.loads(checkingCalendar)[1]}', please summerise and give an answer with this calender with start times. give other details if prompted. talk as if you are talking to lucca: {Calendar}")
        return
    
    globalVariables.coverEars = False

    for _ in range(40):
        if globalVariables.partialPrompt != "" or "Alarm" in globalVariables.display:
            globalVariables.prompt, globalVariables.steveReply = "", ""
            if "Alarm" in globalVariables.display:
                globalVariables.wakeWordDetected = False
            return
        time.sleep(0.1)
    
    globalVariables.prompt, globalVariables.steveReply = "", "" #IMPORTANT
    globalVariables.wakeWordDetected = False

    #Turn off screen if sleep command
    if sleeping and globalVariables.raspberryPi: subprocess.run(["wlr-randr", "--output", "HDMI-A-2", "--off"])
