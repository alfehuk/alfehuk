import globalVariables, time, subprocess, json, threading, animations
from alarmHandling import addAlarm, setRebootAlarm, deleteRebootAlarms, getTime, deleteAlarm, grabAlarms
from calendarHandling import getCalendar
from audioHandling import Say
from elevenlabs.conversational_ai.conversation import (Conversation,ConversationInitiationData)
from elevenlabs.conversational_ai.conversation import ClientTools

def agentResponse(response):
    globalVariables.steveReply = response

def querySteve(query):
    if not globalVariables.inConvo:
        globalVariables.inConvo = True

        ### TOOLS
        client_tools = ClientTools()

        client_tools.register("getTime", getTime)
        client_tools.register("addAlarm", addAlarm)
        client_tools.register("deleteAlarm", deleteAlarm)
        client_tools.register("grabAlarms", grabAlarms)
        client_tools.register("getCalendar", getCalendar)

        globalVariables.conversation = Conversation(
            client=globalVariables.elevenlabs,
            agent_id=globalVariables.agentID,
            requires_auth=True,
            config=globalVariables.config,
            callback_agent_response=agentResponse,
            client_tools=client_tools
        )
        globalVariables.conversation.start_session()
    
    while True:
        try:
            globalVariables.conversation.send_user_message(query)
            break
        except RuntimeError as e:
            if "Session not started or websocket not connected" in str(e):
                time.sleep(0.1)
            else:
                raise
    safety = 0
    while globalVariables.steveReply == "...":
        safety += 1
        time.sleep(0.05)
        if safety > 400:
            break
    return globalVariables.steveReply

def reply(Question=None):
    deleteRebootAlarms()
    globalVariables.steveReply = "..."
    globalVariables.coverEars = True
    if Question == None:
        rawPrompt = globalVariables.prompt[len(globalVariables.wakeWord)+1:]
    else:
        rawPrompt = Question
    sleeping = False
    sleepCommands = ["sleep", "turn off screen", "screen off", "turn screen off", "screen of", "turn screen of", "turn of screen"]
    
    if rawPrompt != "" and rawPrompt != "stop" and rawPrompt not in sleepCommands:
        querySteve(rawPrompt)

    elif rawPrompt in sleepCommands:
        globalVariables.steveReply = "Just remember to press the top button on the right side of me twice when you want me back, ok?"
        setRebootAlarm()
        sleeping = True
    elif rawPrompt == "stop":
        globalVariables.steveReply = ""
        globalVariables.display = "Home"
        globalVariables.wakeWordDetected = False
        return
    else:
        globalVariables.steveReply = "Hi Lucca, how can I help?"

    Say(globalVariables.steveReply)
    
    globalVariables.coverEars = False

    for _ in range(95):
        if globalVariables.partialPrompt != "" or "Alarm" in globalVariables.display:
            globalVariables.prompt = ""
            globalVariables.steveReply = ""
            if "Alarm" in globalVariables.display:
                globalVariables.wakeWordDetected = False
            return
        if _ == 70 and globalVariables.homeTransition == 0: threading.Thread(target=animations.fadeInHomeScreen, daemon=True, name="Fade in home screen").start()
        time.sleep(0.1)

    globalVariables.inConvo = False
    globalVariables.conversation.end_session()
    
    globalVariables.prompt = ""
    globalVariables.steveReply = "" #IMPORTANT
    globalVariables.wakeWordDetected = False

    #Turn off screen if sleep command
    if sleeping and globalVariables.raspberryPi: subprocess.run(["wlr-randr", "--output", "HDMI-A-2", "--off"])
