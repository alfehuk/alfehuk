import datetime, globalVariables, threading, agentProcess, pygame, buttons

#Fonts
dateFont = pygame.font.Font(None, 50)
timeFont = pygame.font.Font(None, 80)
promptFont = pygame.font.Font(None, 45)
alarmFont = pygame.font.SysFont(None, 70)

def homeScreen():
        #RENDER BACKGROUND FIRST!!!!
        #ret, frame = cap.read()
        #if not ret:
        #    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        #    ret, frame = cap.read()
        #frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        #frame = cv2.resize(frame, (1024, 600))
        #surface = pygame.surfarray.make_surface(frame)
        #surface = pygame.transform.rotate(surface, -90)
        #surface = pygame.transform.flip(surface, True, False)
        #screen.blit(surface, (0, 0))

    globalVariables.screen.blit(globalVariables.background, (0, 0))
    Time = datetime.datetime.now()
    date = dateFont.render(Time.strftime("%A, %d %B %Y"), True, (255, 255, 255))
    Tim = timeFont.render(Time.strftime("%H:%M:%S"), True, (255, 255, 255))
    globalVariables.screen.blit(date, (50, 460))
    globalVariables.screen.blit(Tim, (50, 100))
    if globalVariables.videoToPlay:
        pygame.draw.rect(globalVariables.screen, (255, 255, 255), buttons.showButton)
        text = buttons.alertButtonFont.render("?", True, (0, 0, 0))
        text_rect = text.get_rect(center=buttons.showButton.center)
        globalVariables.screen.blit(text, text_rect)

def promptScreen():
    globalVariables.alarmGoing = False
    if globalVariables.prompt == "" and globalVariables.partialPrompt != globalVariables.prompt:
        promptText = globalVariables.partialPrompt
    else:
        promptText = globalVariables.prompt
        if globalVariables.steveReply == "" and globalVariables.prompt != "":
            thread = threading.Thread(target=agentProcess.reply, daemon=True, name="Replier")
            thread.start()
            
    promptText = "Lucca: S" + promptText[1:]
    promptTextRender = promptFont.render(promptText.replace(globalVariables.wakeWord.title(),f"{globalVariables.wakeWord.title()},"), True, (255, 255, 255))

    words = f"{globalVariables.wakeWord.title()}: {globalVariables.steveReply}".split()
    Reply = ""
    y = 330
    for word in words:
        if len(Reply) + len(word) + 1 > 65:
            if "]" in Reply or "[" in Reply or '", ' in Reply: 
                Reply = "Steve: ..."
                y = 330
            steveReplyRender = promptFont.render(Reply, True, (255, 255, 255))
            globalVariables.screen.blit(steveReplyRender, (50, y))
            y += 60
            Reply = word
        else:
            Reply += (" " if Reply else "") + word
    if "]" in Reply or "[" in Reply or '", ' in Reply: 
        Reply = "Steve: ..."
        y = 330

    steveReplyRender = promptFont.render(Reply, True, (255, 255, 255))
    globalVariables.screen.blit(steveReplyRender, (50, y))
    globalVariables.screen.blit(promptTextRender, (50, 240))

def alarmScreen():
    text = alarmFont.render(globalVariables.display.split(":")[1], True, (255, 255, 255))
    text_rect = text.get_rect(center=(1024 // 2, 600 // 2))

    stopText = buttons.stopAlarmFont.render("Stop", True, (0, 0, 0))
    stopBoxRect = stopText.get_rect(center=buttons.stopButton.center)

    pygame.draw.rect(globalVariables.screen, (255, 255, 255), buttons.stopButton)
    globalVariables.screen.blit(text, text_rect)
    globalVariables.screen.blit(stopText, stopBoxRect)