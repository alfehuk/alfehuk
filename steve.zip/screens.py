import datetime, globalVariables,threading,agentProcess

def homeScreen():
        #RENDER BACKGROUND FIRST!!!!
        #ret, frame = cap.read()
        #if not ret:
        #    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        #    ret, frame = cap.read()
        #frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        #frame = cv2.resize(frame, (1024, 600))
        #surface = pygame.surfarray.make_surface(frame)
        #surface = pygame.transform.rotate(surface, -90)
        #surface = pygame.transform.flip(surface, True, False)
        #screen.blit(surface, (0, 0))

    globalVariables.screen.blit(globalVariables.background, (0, 0))
    Time = datetime.datetime.now()
    date = globalVariables.dateFont.render(Time.strftime("%A, %d %B %Y"), True, (255, 255, 255))
    Tim = globalVariables.timeFont.render(Time.strftime("%H:%M:%S"), True, (255, 255, 255))
    globalVariables.screen.blit(date, (50, 460))
    globalVariables.screen.blit(Tim, (50, 100))

def promptScreen():
    globalVariables.alarmGoing = False
    if globalVariables.prompt == "" and globalVariables.partialPrompt != globalVariables.prompt:
        promptText = globalVariables.partialPrompt
    else:
        promptText = globalVariables.prompt
        if globalVariables.steveReply == "" and globalVariables.prompt != "":
            thread = threading.Thread(target=agentProcess.reply, daemon=True, name="Replier")
            thread.start()
            
    promptText = "Lucca: S" + promptText[1:]
    promptTextRender = globalVariables.promptFont.render(promptText.replace(globalVariables.wakeWord.title(),f"{globalVariables.wakeWord.title()},"), True, (255, 255, 255))

    words = f"{globalVariables.wakeWord.title()}: {globalVariables.steveReply}".split()
    Reply = ""
    y = 330
    for word in words:
        if len(Reply) + len(word) + 1 > 45:
            if "]" in Reply or "[" in Reply or '", ' in Reply: 
                Reply = "Steve: ..."
                y = 330
            steveReplyRender = globalVariables.promptFont.render(Reply, True, (255, 255, 255))
            globalVariables.screen.blit(steveReplyRender, (50, y))
            y += 60
            Reply = word
        else:
            Reply += (" " if Reply else "") + word
    if "]" in Reply or "[" in Reply or '", ' in Reply: 
        Reply = "Steve: ..."
        y = 330

    steveReplyRender = globalVariables.promptFont.render(Reply, True, (255, 255, 255))
    globalVariables.screen.blit(steveReplyRender, (50, y))
    globalVariables.screen.blit(promptTextRender, (50, 240))