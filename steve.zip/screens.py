import datetime, globalVariables, threading, agentProcess, pygame, buttons, cv2, os,time

#Fonts
dateFont = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 50)
timeFont = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 80)
promptFont = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 25)
steveFont = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 45)
promptTimeFont = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 15)
alarmFont = pygame.font.SysFont(None, 70)
stopAlarmFont = pygame.font.SysFont(None, 40)

cap = cv2.VideoCapture(os.path.dirname(os.path.abspath(__file__))+"/promptBackground.mp4")
background = pygame.image.load(os.path.dirname(os.path.abspath(__file__)) + "/background.jpg")
background = pygame.transform.scale(background, (1024, 600))

def homeScreen(trans=255):
    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
    backgroundTrans = background.copy()
    backgroundTrans.set_alpha(trans)
    backgroundTrans.set_alpha(trans)
    globalVariables.screen.blit(backgroundTrans, (0, 0))
    Time = datetime.datetime.now()
    date = dateFont.render(Time.strftime("%A, %d %B %Y"), True, (255, 255, 255))
    date.set_alpha(trans)
    Tim = timeFont.render(Time.strftime("%H:%M:%S"), True, (255, 255, 255))
    Tim.set_alpha(trans)
    globalVariables.screen.blit(date, (50, 430))
    globalVariables.screen.blit(Tim, (50, 100))
    if globalVariables.videoToPlay:
        pygame.draw.rect(globalVariables.screen, (255, 255, 255), buttons.showButton, border_radius=5)
        text = buttons.alertButtonFont.render("?", True, (0, 0, 0))
        text_rect = text.get_rect(center=buttons.showButton.center)
        globalVariables.screen.blit(text, text_rect)

def promptScreen():
    ret, frame = cap.read()
    if not ret:
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        ret, frame = cap.read()
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame = cv2.resize(frame, (1024, 600))
    surface = pygame.surfarray.make_surface(frame)
    surface = pygame.transform.rotate(surface, -90)
    surface = pygame.transform.flip(surface, True, False)
    globalVariables.screen.blit(surface, (0, 0))

    globalVariables.alarmGoing = False
    if globalVariables.prompt == "" and globalVariables.partialPrompt != globalVariables.prompt:
        promptText = globalVariables.partialPrompt
    else:
        promptText = globalVariables.prompt
        if globalVariables.steveReply == "" and globalVariables.prompt != "":
            thread = threading.Thread(target=agentProcess.reply, daemon=True, name="Replier")
            thread.start()


    #Scatter
    if promptText != globalVariables.displayedPrompt:
        try:globalVariables.displayedPrompt += promptText[len(globalVariables.displayedPrompt)]
        except:globalVariables.displayedPrompt = promptText
            
    promptText = "Lucca: S" + globalVariables.displayedPrompt[1:]
    promptTextRender = promptFont.render(promptText.replace(globalVariables.wakeWord.title(),f"{globalVariables.wakeWord.title()},"), True, (255, 255, 255))

    pygame.draw.rect(globalVariables.screen, (20, 51, 33), (40, 100, promptFont.size(promptText)[0]+50, 70), border_radius=25)

    steveTitle = promptFont.render(globalVariables.wakeWord.title(), True, (255, 255, 255))
    steveTitleWidth = promptFont.size(globalVariables.wakeWord.title())[0]
    globalVariables.screen.blit(steveTitle, (880, 230))

    currentTime = datetime.datetime.now().strftime("%-H:%M")

    timeText = promptTimeFont.render(currentTime, True, (255, 255, 255))
    timeTextWidth = promptTimeFont.size(currentTime)[0]
    globalVariables.screen.blit(timeText, (1024-(144-steveTitleWidth)-timeTextWidth, 70))

    Reply = globalVariables.steveReply
    newReply = Reply
    y = 0
    if len(newReply) > 40:
        while len(newReply) > 40:
            ggs = 40
            while newReply[ggs] != " ":
                ggs -= 1
            steveAnswer = steveFont.render(newReply[0:ggs], True, (255, 255, 255))
            steveAnswerWidth = steveFont.size(newReply[0:ggs])[0]
            globalVariables.screen.blit(steveAnswer, (1024-(144-steveTitleWidth)-steveAnswerWidth, 300+y))
            newReply = newReply[ggs:]
            y += 100
        steveAnswer = steveFont.render(newReply, True, (255, 255, 255))
        steveAnswerWidth = steveFont.size(newReply)[0]
        globalVariables.screen.blit(steveAnswer, (1024-(144-steveTitleWidth)-steveAnswerWidth, 300+y))
    else:
        steveAnswer = steveFont.render(newReply, True, (255, 255, 255))
        steveAnswerWidth = steveFont.size(newReply)[0]
        globalVariables.screen.blit(steveAnswer, (1024-(144-steveTitleWidth)-steveAnswerWidth, 300))

    promptTextRender = promptFont.render(promptText, True, (255, 255, 255))

    globalVariables.screen.blit(promptTextRender, (65, 120))

def alarmScreen():
    text = alarmFont.render(globalVariables.display.split(":")[1], True, (255, 255, 255))
    text_rect = text.get_rect(center=(1024 // 2, 600 // 2))

    stopText = stopAlarmFont.render("Stop", True, (0, 0, 0))
    stopBoxRect = stopText.get_rect(center=buttons.stopButton.center)

    pygame.draw.rect(globalVariables.screen, (255, 255, 255), buttons.stopButton)
    globalVariables.screen.blit(text, text_rect)
    globalVariables.screen.blit(stopText, stopBoxRect)