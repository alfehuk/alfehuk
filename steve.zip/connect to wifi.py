import pygame
import subprocess
import sys
import urllib.request
import urllib.error
import time

pygame.init()


# ==================================================
# SETTINGS
# ==================================================

WIDTH = 800
HEIGHT = 480

screen = pygame.display.set_mode(
    (WIDTH, HEIGHT)
)

pygame.display.set_caption(
    "Wi-Fi Setup"
)

clock = pygame.time.Clock()


# ==================================================
# FONTS
# ==================================================

TITLE_FONT = pygame.font.Font(
    None,
    42
)

FONT = pygame.font.Font(
    None,
    28
)

SMALL_FONT = pygame.font.Font(
    None,
    22
)

KEY_FONT = pygame.font.Font(
    None,
    22
)


# ==================================================
# COLOURS
# ==================================================

BLACK = (15, 15, 15)

DARK_GREY = (30, 30, 30)

GREY = (55, 55, 55)

LIGHT_GREY = (180, 180, 180)

WHITE = (240, 240, 240)

GREEN = (70, 190, 100)

RED = (220, 70, 70)


# ==================================================
# WIFI FUNCTIONS
# ==================================================

def is_wifi_connected():

    try:

        result = subprocess.run(
            [
                "nmcli",
                "-t",
                "-f",
                "TYPE,STATE",
                "device"
            ],
            capture_output=True,
            text=True,
            timeout=5
        )

        for line in result.stdout.splitlines():

            parts = line.split(":")

            if len(parts) >= 2:

                device_type = parts[0]
                state = parts[1]

                if (
                    device_type == "wifi"
                    and state == "connected"
                ):

                    return True

        return False

    except Exception:

        return False


def has_internet():

    """
    Checks whether the Raspberry Pi can actually
    reach the internet.

    This is different from simply being connected
    to Wi-Fi.
    """

    try:

        request = urllib.request.Request(
            "http://connectivitycheck.gstatic.com/generate_204",
            method="GET"
        )

        response = urllib.request.urlopen(
            request,
            timeout=3
        )

        # Google's connectivity check returns
        # HTTP 204 when internet access works.

        return response.status == 204

    except Exception:

        return False


def wifi_and_internet_connected():

    if not is_wifi_connected():

        return False

    return has_internet()


def get_wifi_networks():

    try:

        result = subprocess.run(
            [
                "nmcli",
                "-t",
                "-f",
                "SSID",
                "device",
                "wifi",
                "list"
            ],
            capture_output=True,
            text=True,
            timeout=10
        )

        if result.returncode != 0:

            return [], "Could not scan for Wi-Fi networks."

        networks = []

        for line in result.stdout.splitlines():

            ssid = line.strip()

            if (
                ssid
                and ssid not in networks
            ):

                networks.append(ssid)

        if not networks:

            return [], "No Wi-Fi networks found."

        return networks, None

    except FileNotFoundError:

        return [], "NetworkManager is not installed."

    except subprocess.TimeoutExpired:

        return [], "Wi-Fi scan timed out."

    except Exception as e:

        return [], f"Wi-Fi scan failed: {e}"


def connect_wifi(
    ssid,
    password
):

    try:

        result = subprocess.run(
            [
                "nmcli",
                "device",
                "wifi",
                "connect",
                ssid,
                "password",
                password
            ],
            capture_output=True,
            text=True,
            timeout=30
        )

        if result.returncode != 0:

            error = result.stderr.lower()

            if (
                "secrets were required"
                in error
                or "incorrect"
                in error
                or "802-11-wireless-security"
                in error
            ):

                return (
                    False,
                    "Incorrect password. Please try again."
                )

            if (
                "no network with ssid"
                in error
            ):

                return (
                    False,
                    "That Wi-Fi network is no longer available."
                )

            if (
                "not authorized"
                in error
            ):

                return (
                    False,
                    "Permission denied."
                )

            return (
                False,
                "Could not connect to this network."
            )

        # ------------------------------------------
        # WIFI CONNECTED
        # ------------------------------------------

        # Now make sure there is actually internet.

        for _ in range(10):

            if has_internet():

                return (
                    True,
                    "Connected to the internet."
                )

            time.sleep(1)

        # Wi-Fi connected, but no internet.

        return (
            False,
            "Connected to Wi-Fi, but there is no internet."
        )

    except subprocess.TimeoutExpired:

        return (
            False,
            "Connection timed out."
        )

    except Exception as e:

        return (
            False,
            f"Connection failed: {e}"
        )


# ==================================================
# STARTUP "JOINING WIFI" SCREEN
# ==================================================

screen.fill(BLACK)

draw_startup_font = pygame.font.Font(
    None,
    42
)

startup_text = draw_startup_font.render(
    "Joining WiFi...",
    True,
    WHITE
)

screen.blit(
    startup_text,
    (
        (WIDTH - startup_text.get_width()) // 2,
        190
    )
)

startup_small = SMALL_FONT.render(
    "Checking for a saved network",
    True,
    LIGHT_GREY
)

screen.blit(
    startup_small,
    (
        (WIDTH - startup_small.get_width()) // 2,
        240
    )
)

pygame.display.flip()


# ==================================================
# GIVE NETWORKMANAGER TIME TO AUTO-CONNECT
# ==================================================

startup_start = time.time()

STARTUP_TIMEOUT = 8


while (
    time.time() - startup_start
    < STARTUP_TIMEOUT
):

    # Check actual internet connection.

    if wifi_and_internet_connected():

        pygame.quit()

        #HERE IS THE EXIT POINT
        sys.exit()

    # Process touchscreen/window events
    # so the screen doesn't look frozen.

    for event in pygame.event.get():

        if event.type == pygame.QUIT:

            pygame.quit()
            sys.exit()

    clock.tick(10)


# ==================================================
# GET WIFI NETWORKS
# ==================================================

networks, scan_error = (
    get_wifi_networks()
)

selected_network = None

password = ""

password_active = False

keyboard_visible = False

shift_active = False

symbol_mode = False

dropdown_open = False

connecting = False

message = (
    scan_error
    if scan_error
    else "Select a Wi-Fi network"
)

message_colour = (
    RED
    if scan_error
    else LIGHT_GREY
)


# ==================================================
# UI FUNCTIONS
# ==================================================

def draw_text(
    text,
    font,
    colour,
    x,
    y
):

    surface = font.render(
        text,
        True,
        colour
    )

    screen.blit(
        surface,
        (x, y)
    )


def draw_button(
    rect,
    text,
    enabled=True
):

    colour = (
        GREY
        if enabled
        else DARK_GREY
    )

    pygame.draw.rect(
        screen,
        colour,
        rect,
        border_radius=7
    )

    text_surface = FONT.render(
        text,
        True,
        WHITE
    )

    x = rect.x + (
        rect.width
        - text_surface.get_width()
    ) // 2

    y = rect.y + (
        rect.height
        - text_surface.get_height()
    ) // 2

    screen.blit(
        text_surface,
        (x, y)
    )


# ==================================================
# KEYBOARD
# ==================================================

LETTER_ROWS = [

    [
        "q", "w", "e", "r", "t",
        "y", "u", "i", "o", "p"
    ],

    [
        "a", "s", "d", "f", "g",
        "h", "j", "k", "l"
    ],

    [
        "shift",
        "z", "x", "c", "v",
        "b", "n", "m",
        "backspace"
    ],

    [
        "symbols",
        "space",
        "enter"
    ]
]


SYMBOL_ROWS = [

    [
        "1", "2", "3", "4", "5",
        "6", "7", "8", "9", "0"
    ],

    [
        "!", "@", "#", "$", "%",
        "^", "&", "*", "(", ")"
    ],

    [
        "-", "_", "=", "+", "[",
        "]", "{", "}", "\\", "|"
    ],

    [
        ";", ":", "'", '"', ",",
        ".", "<", ">", "/", "?"
    ],

    [
        "letters",
        "space",
        "enter"
    ]
]


SHIFT_SYMBOLS = {

    "1": "!",
    "2": "@",
    "3": "#",
    "4": "$",
    "5": "%",
    "6": "^",
    "7": "&",
    "8": "*",
    "9": "(",
    "0": ")",

    "-": "_",
    "_": "_",

    "=": "+",
    "+": "+",

    "[": "{",
    "]": "}",

    "{": "{",
    "}": "}",

    "\\": "|",
    "|": "|",

    ";": ":",
    ":": ":",

    "'": '"',
    '"': '"',

    ",": "<",
    "<": "<",

    ".": ">",
    ">": ">",

    "/": "?",
    "?": "?"
}


# ==================================================
# KEYBOARD RECTANGLES
# ==================================================

def get_keyboard_rects():

    rects = []

    keyboard_y = 315

    key_height = 28

    gap = 4

    if symbol_mode:

        rows = SYMBOL_ROWS

    else:

        rows = LETTER_ROWS

    for row_index, row in enumerate(rows):

        # ------------------------------------------
        # BOTTOM ROW
        # ------------------------------------------

        if row_index == len(rows) - 1:

            mode_width = 100

            space_width = 390

            enter_width = 150

            total_width = (
                mode_width
                + space_width
                + enter_width
                + gap * 2
            )

            x = (
                WIDTH
                - total_width
            ) // 2

            # Mode

            rect = pygame.Rect(
                x,
                keyboard_y,
                mode_width,
                key_height
            )

            rects.append(
                (row[0], rect)
            )

            x += (
                mode_width
                + gap
            )

            # Space

            rect = pygame.Rect(
                x,
                keyboard_y,
                space_width,
                key_height
            )

            rects.append(
                ("space", rect)
            )

            x += (
                space_width
                + gap
            )

            # Enter

            rect = pygame.Rect(
                x,
                keyboard_y,
                enter_width,
                key_height
            )

            rects.append(
                ("enter", rect)
            )

            keyboard_y += (
                key_height
                + gap
            )

            continue

        # ------------------------------------------
        # SHIFT ROW
        # ------------------------------------------

        if (
            not symbol_mode
            and row_index == 2
        ):

            shift_width = 65

            backspace_width = 90

            normal_count = (
                len(row) - 2
            )

            available_width = (
                WIDTH - 80
            )

            remaining_width = (
                available_width
                - shift_width
                - backspace_width
                - gap * (
                    len(row) - 1
                )
            )

            normal_width = (
                remaining_width
                // normal_count
            )

            total_width = (
                shift_width
                + backspace_width
                + normal_width
                * normal_count
                + gap * (
                    len(row) - 1
                )
            )

            x = (
                WIDTH
                - total_width
            ) // 2

            for key in row:

                if key == "shift":

                    width = shift_width

                elif key == "backspace":

                    width = backspace_width

                else:

                    width = normal_width

                rect = pygame.Rect(
                    x,
                    keyboard_y,
                    width,
                    key_height
                )

                rects.append(
                    (key, rect)
                )

                x += (
                    width
                    + gap
                )

        # ------------------------------------------
        # NORMAL ROW
        # ------------------------------------------

        else:

            available_width = (
                WIDTH - 80
            )

            key_width = (
                available_width
                - gap * (
                    len(row) - 1
                )
            ) // len(row)

            total_width = (
                key_width
                * len(row)
                + gap * (
                    len(row) - 1
                )
            )

            x = (
                WIDTH
                - total_width
            ) // 2

            for key in row:

                rect = pygame.Rect(
                    x,
                    keyboard_y,
                    key_width,
                    key_height
                )

                rects.append(
                    (key, rect)
                )

                x += (
                    key_width
                    + gap
                )

        keyboard_y += (
            key_height
            + gap
        )

    return rects


# ==================================================
# DRAW KEYBOARD
# ==================================================

def draw_keyboard():

    rects = get_keyboard_rects()

    for key, rect in rects:

        key_colour = DARK_GREY

        if (
            key == "shift"
            and shift_active
        ):

            key_colour = GREY

        pygame.draw.rect(
            screen,
            key_colour,
            rect,
            border_radius=5
        )

        if key == "backspace":

            display_key = "←"

        elif key == "shift":

            display_key = "SHIFT"

        elif key == "symbols":

            display_key = "?123"

        elif key == "letters":

            display_key = "ABC"

        elif key == "space":

            display_key = "SPACE"

        elif key == "enter":

            display_key = "ENTER"

        else:

            display_key = key

            if (
                not symbol_mode
                and shift_active
                and len(display_key) == 1
            ):

                display_key = (
                    display_key.upper()
                )

            elif (
                symbol_mode
                and shift_active
                and display_key
                in SHIFT_SYMBOLS
            ):

                display_key = (
                    SHIFT_SYMBOLS[
                        display_key
                    ]
                )

        text_surface = KEY_FONT.render(
            display_key,
            True,
            WHITE
        )

        text_x = (
            rect.x
            + (
                rect.width
                - text_surface.get_width()
            ) // 2
        )

        text_y = (
            rect.y
            + (
                rect.height
                - text_surface.get_height()
            ) // 2
        )

        screen.blit(
            text_surface,
            (
                text_x,
                text_y
            )
        )

    return rects


# ==================================================
# WIFI CHECK TIMER
# ==================================================

last_wifi_check = 0


# ==================================================
# MAIN LOOP
# ==================================================

running = True

while running:

    # --------------------------------------------------
    # CHECK WIFI + INTERNET EVERY SECOND
    # --------------------------------------------------

    current_time = (
        pygame.time.get_ticks()
    )

    if (
        current_time
        - last_wifi_check
        >= 1000
    ):

        last_wifi_check = current_time

        if wifi_and_internet_connected():

            pygame.quit()

            #HERE IS THE EXIT POINT
            sys.exit()

    # --------------------------------------------------
    # BACKGROUND
    # --------------------------------------------------

    screen.fill(BLACK)

    # --------------------------------------------------
    # TITLE
    # --------------------------------------------------

    draw_text(
        "Wi-Fi Setup",
        TITLE_FONT,
        WHITE,
        40,
        20
    )

    # --------------------------------------------------
    # NETWORK
    # --------------------------------------------------

    draw_text(
        "Wi-Fi Network",
        SMALL_FONT,
        LIGHT_GREY,
        40,
        70
    )

    dropdown_rect = pygame.Rect(
        40,
        95,
        720,
        45
    )

    pygame.draw.rect(
        screen,
        DARK_GREY,
        dropdown_rect,
        border_radius=7
    )

    draw_text(
        selected_network
        if selected_network
        else "Select a network...",
        FONT,
        WHITE,
        55,
        107
    )

    pygame.draw.polygon(
        screen,
        LIGHT_GREY,
        [
            (735, 112),
            (750, 112),
            (742, 122)
        ]
    )

    # --------------------------------------------------
    # DROPDOWN
    # --------------------------------------------------

    if dropdown_open:

        option_y = 140

        for network in networks[:6]:

            option_rect = pygame.Rect(
                40,
                option_y,
                720,
                36
            )

            pygame.draw.rect(
                screen,
                DARK_GREY,
                option_rect
            )

            draw_text(
                network,
                SMALL_FONT,
                WHITE,
                55,
                option_y + 8
            )

            option_y += 36

    # --------------------------------------------------
    # PASSWORD
    # --------------------------------------------------

    password_y = (
        150
        if dropdown_open
        else 155
    )

    draw_text(
        "Password",
        SMALL_FONT,
        LIGHT_GREY,
        40,
        password_y
    )

    password_rect = pygame.Rect(
        40,
        password_y + 25,
        720,
        45
    )

    pygame.draw.rect(
        screen,
        DARK_GREY,
        password_rect,
        border_radius=7
    )

    if password:

        hidden_password = (
            "•" * len(password)
        )

        draw_text(
            hidden_password,
            FONT,
            WHITE,
            55,
            password_y + 36
        )

    else:

        draw_text(
            "Enter password...",
            FONT,
            (100, 100, 100),
            55,
            password_y + 36
        )

    # --------------------------------------------------
    # CONNECT BUTTON
    # --------------------------------------------------

    if keyboard_visible:

        connect_y = 245

    else:

        connect_y = 230

    connect_rect = pygame.Rect(
        40,
        connect_y,
        720,
        45
    )

    draw_button(
        connect_rect,
        (
            "Connecting..."
            if connecting
            else "Connect"
        ),
        not connecting
    )

    # --------------------------------------------------
    # MESSAGE
    # --------------------------------------------------

    draw_text(
        message,
        SMALL_FONT,
        message_colour,
        40,
        connect_y + 53
    )

    # --------------------------------------------------
    # KEYBOARD
    # --------------------------------------------------

    keyboard_rects = []

    if keyboard_visible:

        keyboard_rects = (
            draw_keyboard()
        )

    # --------------------------------------------------
    # EVENTS
    # --------------------------------------------------

    for event in pygame.event.get():

        if event.type == pygame.QUIT:

            running = False

        elif (
            event.type
            == pygame.MOUSEBUTTONDOWN
        ):

            mouse = event.pos

            keyboard_key_pressed = False

            # ------------------------------------------
            # KEYBOARD
            # ------------------------------------------

            if keyboard_visible:

                for key, rect in keyboard_rects:

                    if rect.collidepoint(mouse):

                        keyboard_key_pressed = True

                        # BACKSPACE

                        if key == "backspace":

                            password = (
                                password[:-1]
                            )

                        # SHIFT

                        elif key == "shift":

                            shift_active = (
                                not shift_active
                            )

                        # SYMBOLS

                        elif key == "symbols":

                            symbol_mode = True

                            shift_active = False

                        # LETTERS

                        elif key == "letters":

                            symbol_mode = False

                            shift_active = False

                        # SPACE

                        elif key == "space":

                            password += " "

                        # ENTER

                        elif key == "enter":

                            password_active = False

                            keyboard_visible = False

                        # CHARACTER

                        else:

                            character = key

                            if not symbol_mode:

                                if shift_active:

                                    character = (
                                        character.upper()
                                    )

                                    shift_active = False

                            else:

                                if (
                                    shift_active
                                    and character
                                    in SHIFT_SYMBOLS
                                ):

                                    character = (
                                        SHIFT_SYMBOLS[
                                            character
                                        ]
                                    )

                                    shift_active = False

                            password += character

                        break

            if keyboard_key_pressed:

                continue

            # ------------------------------------------
            # PASSWORD FIELD
            # ------------------------------------------

            if password_rect.collidepoint(
                mouse
            ):

                password_active = True

                keyboard_visible = True

                dropdown_open = False

                continue

            # ------------------------------------------
            # WIFI DROPDOWN
            # ------------------------------------------

            if dropdown_rect.collidepoint(
                mouse
            ):

                dropdown_open = (
                    not dropdown_open
                )

                keyboard_visible = False

                password_active = False

                continue

            # ------------------------------------------
            # WIFI OPTIONS
            # ------------------------------------------

            if dropdown_open:

                option_y = 140

                for network in networks[:6]:

                    option_rect = pygame.Rect(
                        40,
                        option_y,
                        720,
                        36
                    )

                    if option_rect.collidepoint(
                        mouse
                    ):

                        selected_network = (
                            network
                        )

                        dropdown_open = False

                        message = (
                            f"Selected: {network}"
                        )

                        message_colour = (
                            LIGHT_GREY
                        )

                        break

                    option_y += 36

                continue

            # ------------------------------------------
            # CONNECT
            # ------------------------------------------

            if connect_rect.collidepoint(
                mouse
            ):

                if connecting:

                    continue

                if not selected_network:

                    message = (
                        "Please select a Wi-Fi network."
                    )

                    message_colour = RED

                elif not password:

                    message = (
                        "Please enter the Wi-Fi password."
                    )

                    message_colour = RED

                    password_active = True

                    keyboard_visible = True

                else:

                    connecting = True

                    message = (
                        "Joining WiFi..."
                    )

                    message_colour = (
                        LIGHT_GREY
                    )

                    pygame.display.flip()

                    success, result = (
                        connect_wifi(
                            selected_network,
                            password
                        )
                    )

                    connecting = False

                    if success:

                        message = (
                            "Internet connected!"
                        )

                        message_colour = GREEN

                        pygame.display.flip()

                        pygame.time.wait(
                            800
                        )

                        pygame.quit()

                        #HERE IS THE EXIT POINT
                        sys.exit()

                    else:

                        message = result

                        message_colour = RED

                        password = ""

                        password_active = True

                        keyboard_visible = True

            # ------------------------------------------
            # CLICK OFF
            # ------------------------------------------

            else:

                if keyboard_visible:

                    keyboard_visible = False

                    password_active = False

    pygame.display.flip()

    clock.tick(60)


pygame.quit()

sys.exit()