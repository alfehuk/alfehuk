import os, globalVariables, pygame, shutil, time

def updateVoskUS022():
    alert = "updating steve to vosk-model-en-us-0.22..."
    alertText = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 45).render(alert, True, (255, 255, 255))
    alertWidth = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 45).size(alert)[0]
    globalVariables.screen.blit(alertText, ((1024/2)-(alertWidth/2), 275))
    pygame.display.flip()
    import urllib,zipfile
    url = "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22.zip"
    output = os.path.dirname(os.path.abspath(__file__))+"/vosk-model-en-us-0.22.zip"
    urllib.request.urlretrieve(url, output)
    time.sleep(2)
    with zipfile.ZipFile(os.path.dirname(os.path.abspath(__file__))+"/vosk-model-en-us-0.22.zip", "r") as zip_ref:
        zip_ref.extractall(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def deleteRNNLMVoskUS022():
   shutil.rmtree(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/vosk-model-en-us-0.22/rnnlm")

def updateVoskUS022lgraph():
    alert = "updating steve to vosk-model-en-us-0.22-lgraph..."
    alertText = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 45).render(alert, True, (255, 255, 255))
    alertWidth = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 45).size(alert)[0]
    globalVariables.screen.blit(alertText, ((1024/2)-(alertWidth/2), 275))
    pygame.display.flip()
    import urllib,zipfile
    url = "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip"
    output = os.path.dirname(os.path.abspath(__file__))+"/vosk-model-en-us-0.22-lgraph.zip"
    urllib.request.urlretrieve(url, output)
    with zipfile.ZipFile(os.path.dirname(os.path.abspath(__file__))+"/vosk-model-en-us-0.22-lgraph.zip", "r") as zip_ref:
     zip_ref.extractall(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))