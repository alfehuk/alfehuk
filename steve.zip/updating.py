import os, globalVariables, pygame

def updateVosk():
    if not os.path.exists(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/vosk-model-en-us-0.22"):
        alert = "upgrading steve's listening abilities..."
        alertText = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 45).render(alert, True, (255, 255, 255))
        alertWidth = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 45).size(alert)[0]
        globalVariables.screen.blit(alertText, ((1024/2)-(alertWidth/2), 275))
        pygame.display.flip()
        import urllib,zipfile
        url = "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22.zip"
        output = os.path.dirname(os.path.abspath(__file__))+"/vosk-model-en-us-0.22.zip"
        urllib.request.urlretrieve(url, output)
        with zipfile.ZipFile(os.path.dirname(os.path.abspath(__file__))+"/vosk-model-en-us-0.22.zip", "r") as zip_ref:
            zip_ref.extractall(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))