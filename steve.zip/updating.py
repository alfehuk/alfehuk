import os, globalVariables, pygame, shutil, time

def updateVosk(url):
    modelName = url.split("/")[-1].replace(".zip","")
    alert = f"updating steve to {modelName}..."
    alertText = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 45).render(alert, True, (255, 255, 255))
    alertWidth = pygame.font.Font(os.path.join(os.path.dirname(__file__), "fonts", "GoogleSans-Regular.ttf"), 45).size(alert)[0]
    globalVariables.screen.blit(alertText, ((1024/2)-(alertWidth/2), 275))
    pygame.display.flip()
    import urllib,zipfile
    output = os.path.dirname(os.path.abspath(__file__))+f"/{modelName}.zip"
    urllib.request.urlretrieve(url, output)
    with zipfile.ZipFile(os.path.dirname(os.path.abspath(__file__))+f"/{modelName}.zip", "r") as zip_ref:
     zip_ref.extractall(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def deleteVoskRNNLM(modelName):
   shutil.rmtree(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+f"/{modelName}/rnnlm")