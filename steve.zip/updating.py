import os

def updateVosk():
    if not os.path.exists(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/vosk-model-en-us-0.22"):
        import urllib,zipfile
        url = "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22.zip"
        output = os.path.dirname(os.path.abspath(__file__))+"/vosk-model-en-us-0.22.zip"
        urllib.request.urlretrieve(url, output)
        with zipfile.ZipFile(os.path.dirname(os.path.abspath(__file__))+"/vosk-model-en-us-0.22.zip", "r") as zip_ref:
            zip_ref.extractall(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))