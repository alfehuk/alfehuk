from moonshine_voice import MicTranscriber

def on_text(text):
    print("Live:", text)

def on_line(line):
    print("Final:", line.text)

mic = (
    MicTranscriber()
    .language("en")
    .on_text(on_text)
    .on_line(on_line)
)

mic.load()
mic.start()

try:
    input("Listening... Press ENTER to stop.\n")
finally:
    mic.stop()