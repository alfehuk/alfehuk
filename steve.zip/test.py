import random,time,os
sentence = ["hello","lol","my","name","is","steve"]
screen = ""
while len(sentence) != 0:
    print(screen)
    if random.randint(0,10) == 1:
        screen += sentence[0] + " "
        sentence.remove(sentence[0])
    time.sleep(.1)
    os.system("clear")
print(screen)