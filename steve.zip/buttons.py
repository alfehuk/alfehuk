import subprocess, globalVariables, pygame, os
from aLittleShow import startShow

#Fonts
alertButtonFont = pygame.font.Font(None, 40)

#Home screen buttons
updateButton = pygame.Rect(950, 526, 50, 50)
showButton = pygame.Rect(1024-950-50, 526, 50, 50)
stopButton = pygame.Rect((1024//2)-(150//2), (600//2)-(60//2)+150, 150, 60)

def pressed(x,y):
    if updateButton.collidepoint(x, y) and globalVariables.updateAvailable:
        subprocess.run("echo 'steve' | sudo -S reboot",shell=True)
    if showButton.collidepoint(x, y) and globalVariables.videoToPlay:
        f = open(os.path.dirname(os.path.abspath(__file__))+"/theShow/amIShowing.txt","w")
        f.write("0")
        f.close()
        globalVariables.videoToPlay = False
        startShow()
    if stopButton.collidepoint(x, y) and globalVariables.alarmGoing:
        globalVariables.display = "Home"