import globalVariables, queue, subprocess, time, json
if globalVariables.raspberryPi:import alsaaudio
import sounddevice as sd
from elevenlabs.play import play
from vosk import Model, KaldiRecognizer

#MAC CALLBACK
def callback(indata, frames, time_info, status):
    if status:print("Audio status:", status)
    try:
        globalVariables.q.put_nowait(bytes(indata))
    except queue.Full:
        try:
            globalVariables.q.get_nowait()
            globalVariables.q.put_nowait(bytes(indata))
        except queue.Empty:pass
        except queue.Full:pass



def Say(toSay):
    if globalVariables.raspberryPi:
        audio = globalVariables.elevenlabs.text_to_speech.convert(
        text=toSay,
        voice_id="wDo1eqIeXkmQd5FHP1x4",
        model_id="eleven_flash_v2_5",
        output_format="pcm_48000")
    else:
        audio = globalVariables.elevenlabs.text_to_speech.convert(
            text=toSay,
            voice_id="wDo1eqIeXkmQd5FHP1x4",
            model_id="eleven_flash_v2_5",
            output_format="mp3_44100_128")
    if globalVariables.raspberryPi:
        audio = b"".join(audio)
        silence = b"\x00" * int(48000 * 2 * 0.9)
        audio = silence + audio
        subprocess.run(
            [
                "aplay",
                "-D", "default",
                "-f", "S16_LE",
                "-r", "48000",
                "-c", "1"
            ],
            input=audio
        )
    else:
        play(audio)

def processAudio(data):
    if globalVariables.coverEars:
        time.sleep(0.01)
        return
    
    if globalVariables.recognizer.AcceptWaveform(data):
        final = json.loads(globalVariables.recognizer.Result())["text"]
        if globalVariables.wakeWord in final:
            splitFinal = final.split(globalVariables.wakeWord,1)[1]
            globalVariables.prompt = globalVariables.wakeWord + splitFinal
            globalVariables.partialPrompt = ""
    else:
        partial = json.loads(globalVariables.recognizer.PartialResult())["partial"]
        if globalVariables.wakeWord in partial:
            globalVariables.prompt = ""
            globalVariables.wakeWordDetected = True
            splitPartial = partial.split(globalVariables.wakeWord,1)[1]
            globalVariables.partialPrompt = globalVariables.wakeWord + splitPartial

def listenForWakeWord():
    while globalVariables.running:
        try:
            if globalVariables.raspberryPi:
                mic = alsaaudio.PCM(
                    type=alsaaudio.PCM_CAPTURE,
                    mode=alsaaudio.PCM_NORMAL,
                    device="plughw:3,0"
                )
                mic.setchannels(1)
                mic.setrate(16000)
                mic.setformat(alsaaudio.PCM_FORMAT_S16_LE)
                mic.setperiodsize(1600)
                while globalVariables.running:
                    length, data = mic.read()
                    if length > 0:
                        processAudio(data)
            else:
                with sd.RawInputStream(
                    device=0,
                    samplerate=16000,
                    blocksize=4096,
                    dtype="int16",
                    channels=1,
                    callback=callback
                ):
                    while globalVariables.running:
                        data = globalVariables.q.get()
                        processAudio(data)

        except Exception as e:
            print("Audio stream error:", e)
            globalVariables.recognizer = KaldiRecognizer(globalVariables.model, 16000)
            time.sleep(1)
         