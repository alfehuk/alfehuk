import json, datetime
from caldav import DAVClient

def getCalendar(parameters):
    startDate = parameters.get("startDate")
    endDate = parameters.get("endDate")
    ICLOUD_EMAIL = "alfiemdt@icloud.com"
    APP_PASSWORD = "whmy-dpqo-lryr-yfzv"
    client = DAVClient(
        url="https://caldav.icloud.com",
        username=ICLOUD_EMAIL,
        password=APP_PASSWORD
    )
    Events = ""
    calendar = next(c for c in client.principal().calendars() if c.name == "Alfie & Lucca")
    events = calendar.search(
        start=datetime.datetime.strptime(startDate, "%d/%m/%Y %H:%M:%S"),
        end=datetime.datetime.strptime(endDate, "%d/%m/%Y %H:%M:%S"),
        event=True
    )
    for event in events:
        vevent = event.vobject_instance.vevent
        title = str(vevent.summary.value)
        start_time = vevent.dtstart.value
        end_time = vevent.dtend.value
        if "Alfie:" not in title and "Lucca:" not in title:
            title = f"Lucca and Alfie both have {title} together"
        Events += f"{title}, at {start_time} until {end_time}. "
    Events = Events.replace("Lucca:","Lucca has an event:").replace("Alfie:", "Alfie has an event:")
    return Events