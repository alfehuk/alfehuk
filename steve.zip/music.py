import pygame, os

pygame.mixer.init()
pygame.mixer.music.load(os.path.dirname(os.path.abspath(__file__))+"/Mama y papa.mp3")

pygame.mixer.music.play(loops=-1)  # Loop forever

# Stop it whenever you want
input("Press Enter to stop...")
pygame.mixer.music.stop()