import subprocess, sys, os, pygame, cv2, datetime
from datetime import timedelta
import os, threading
from vosk import Model, KaldiRecognizer
import sounddevice as sd
import queue, time, json, random, platform, requests
from elevenlabs.client import ElevenLabs
from elevenlabs.play import play
from elevenlabs.conversational_ai.conversation import (Conversation,ConversationInitiationData)
from scipy.signal import resample_poly
import numpy as np
from caldav import DAVClient

q = queue.Queue()
model = Model(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/vosk-model-en-gb-0.1")
recognizer = KaldiRecognizer(model, 16000)

def find_mic():
    devices = sd.query_devices()

    for i, device in enumerate(devices):
        if "SF-558" in device["name"] and device["max_input_channels"] > 0:
            return i

    raise RuntimeError("SF-558 microphone not found")

if platform.system() != "Darwin":
    index = find_mic()
else:
    index = 0

###Any stupid question that you can't do (apart from cancelling or changing alarms) can you say "I'm a box mate. I can only do so much."

APIKEY = "sk_47e85c08567eb9093e9ae4ed448f396e89f1355cd2d97846"
elevenlabs = ElevenLabs(api_key=APIKEY)
agentID = "agent_9101m0t53pkcf5r9pse8ptq8p3rx"
config = ConversationInitiationData(conversation_config_override={"conversation": {"text_only": True}})

wakeWordDetected = False
prompt = ""
partialPrompt = ""
steveReply = ""
wakeWord = "steve"
coverEars = False
updateAvailable = False

alarms = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/alarms.json"
data = ""
while True:
    try:
        with open(alarms, "r") as file:
            data = json.load(file)
            break
    except:
        with open(alarms, "a") as file:
            file.write("[]")
Alarms =  [i for i in data]

pygame.init()
pygame.mixer.quit()
screen = pygame.display.set_mode((1024, 600))
pygame.display.set_caption("Video")
running = True
clock = pygame.time.Clock()
display = "Home"
cap = cv2.VideoCapture(os.path.dirname(os.path.abspath(__file__))+"/Sample background.mp4")

if platform.system() != "Darwin":
    subprocess.run(["sudo", "-S", "sh", "-c", "echo none > /sys/class/leds/PWR/trigger"], input="steve\n", text=True)
    subprocess.run(["sudo", "-S", "sh", "-c", "echo 0 > /sys/class/leds/PWR/brightness"], input="steve\n", text=True)
    subprocess.run(["sudo", "-S", "sh", "-c", "echo none > /sys/class/leds/ACT/trigger"], input="steve\n", text=True)
    subprocess.run(["sudo", "-S", "sh", "-c", "echo 0 > /sys/class/leds/ACT/brightness"], input="steve\n", text=True)

def getCalendar(inp):
    Inp = json.loads(inp)
    startDate = Inp[2]
    endDate = Inp[3]
    ICLOUD_EMAIL = "alfiemdt@icloud.com"
    APP_PASSWORD = "whmy-dpqo-lryr-yfzv"
    client = DAVClient(
        url="https://caldav.icloud.com",
        username=ICLOUD_EMAIL,
        password=APP_PASSWORD
    )
    Events = ""
    calendar = next(c for c in client.principal().calendars() if c.name == "Alfie & Lucca")
    events = calendar.search(
        start=datetime.datetime.strptime(startDate, "%d/%m/%Y %H:%M:%S"),
        end=datetime.datetime.strptime(endDate, "%d/%m/%Y %H:%M:%S"),
        event=True
    )
    for event in events:
        vevent = event.vobject_instance.vevent
        title = str(vevent.summary.value)
        start_time = vevent.dtstart.value
        end_time = vevent.dtend.value
        if "Alfie:" not in title and "Lucca:" not in title:
            title = f"Lucca and Alfie both have {title} together"
        Events += f"{title}, at {start_time} until {end_time}. "
    Events = Events.replace("Lucca:","Lucca has an event:").replace("Alfie:", "Alfie has an event:")
    return Events

def callback2(indata, frames, time, status):
    q.put(bytes(indata))

def callback(indata, frames, time_info, status):
    if status: print(status)
    audio_48k = np.frombuffer(indata, dtype=np.int16)
    audio_16k = resample_poly(audio_48k,16000,48000).astype(np.int16)
    q.put(bytes(audio_16k))

def checkAlarms():
    global display, Alarms
    for alarm in Alarms:
        if alarm["time"] == datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"):
            while True:
                try:
                    with open(alarms, "r") as file:
                        data = json.load(file)
                        break
                except:
                    with open(alarms, "a") as file:
                        file.write("[]")
            display = "Alarm:"+alarm["name"]
            data.remove(alarm)
            Alarms.remove(alarm)
            with open(alarms, "w") as file:
                json.dump(data, file, indent=4)

def addAlarm(inp):
    global alarms, Alarms
    inp = json.loads(inp)
    if inp[0] == "Timer":
        timerTime = inp[2].split(" ")[1].split(":")
        inp[2] = datetime.datetime.now() + timedelta(
            hours=int(timerTime[0]),
            minutes=int(timerTime[1]),
            seconds=int(timerTime[2])
        ) + timedelta(
            days=(
                datetime.datetime.strptime(
                    inp[2].split(" ")[0],
                    "%d/%m/%Y"
                ) - datetime.datetime.strptime(
                    str(datetime.datetime.now()).split(" ")[0],
                    "%Y-%m-%d")
            ).days
        )
        inp[2] = inp[2].strftime("%d/%m/%Y %H:%M:%S")
    if inp[1] == "":
        inp[1] = inp[0]
    Data = {"name": inp[1],"time": inp[2]}
    while True:
        try:
            with open(alarms, "r") as file:
                data = json.load(file)
                break
        except:
            with open(alarms, "a") as file:
                file.write("[]")
    Alarms.append(Data)
    data.append(Data)
    with open(alarms, "w") as file:
        json.dump(data, file, indent=4)

def agentResponse(response):
    global steveReply
    steveReply = response

def Say(toSay):
    if platform.system() != "Darwin":
        audio = elevenlabs.text_to_speech.convert(
        text=toSay,
        voice_id="wDo1eqIeXkmQd5FHP1x4",
        model_id="eleven_flash_v2_5",
        output_format="pcm_48000")
    else:
        audio = elevenlabs.text_to_speech.convert(
            text=toSay,
            voice_id="wDo1eqIeXkmQd5FHP1x4",
            model_id="eleven_flash_v2_5",
            output_format="mp3_44100_128")
    if platform.system() != "Darwin":
        audio = b"".join(audio)
        silence = b"\x00" * int(48000 * 2 * 0.5)
        audio = silence + audio
        subprocess.run(
            [
                "aplay",
                "-D", "default",
                "-f", "S16_LE",
                "-r", "48000",
                "-c", "1"
            ],
            input=audio
        )
    else:
        play(audio)

def reply(Question=None):
    global prompt, steveReply, wakeWordDetected, partialPrompt, coverEars, display
    steveReply = "..."
    conversation = Conversation(
    client=elevenlabs,
    agent_id=agentID,
    requires_auth=True,
    config=config,
    callback_agent_response=agentResponse
    )
    coverEars = True
    conversation.start_session()
    if Question == None:
        Prompt = prompt[len(wakeWord)+1:]
    else:
        Prompt = Question
    sleepCommands = ["sleep", "turn off screen", "screen off", "turn screen off", "screen of", "turn screen of", "turn of screen"]
    if prompt != "steve" and Prompt != "stop" and Prompt not in sleepCommands:
        while True:
            try:
                conversation.send_user_message(Prompt)
                break
            except RuntimeError as e:
                if "Session not started or websocket not connected" in str(e):
                    time.sleep(0.1)
                else:
                    raise
        while steveReply == "...":
            time.sleep(0.05)

    elif Prompt in sleepCommands:
        wakeWordDetected = False
        steveReply = ""
        display = "Sleep"
        return
    elif Prompt == "stop":
        steveReply = ""
        display = "Home"
        wakeWordDetected = False
        return
    else:
        steveReply = "Hi Lucca, how can I help?"

    Alarm = False
    calENDER = False
    if '["Alarm"' in steveReply or '["Timer"' in steveReply:
        Alarm = True
        inp = steveReply.split(" [")
        steveReply = inp[0]
    elif '["Calendar"' in steveReply:
        calENDER = steveReply
        steveReply = "Checking your calendar..."

    Say(steveReply)

    if Alarm:
        addAlarm(f"[{inp[1]}")
    if calENDER != False:
        Calendar = getCalendar(calENDER)
        reply(f"lucca is asking '{json.loads(calENDER)[1]}', please summerise and give an answer with this calender with start times. give other details if prompted. talk as if you are talking to lucca: {Calendar}")
        return

    coverEars = False
    conversation.end_session()

    for _ in range(40):
        if partialPrompt != "" or "Alarm" in display:
            prompt, steveReply = "", ""
            if "Alarm" in display:
                wakeWordDetected = False
            return
        time.sleep(0.1)
    prompt, steveReply = "", "" #IMPORTANT
    wakeWordDetected = False

def homeScreen():
    #RENDER BACKGROUND FIRST!!!!
    ret, frame = cap.read()
    if not ret:
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        ret, frame = cap.read()
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame = cv2.resize(frame, (1024, 600))
    surface = pygame.surfarray.make_surface(frame)
    surface = pygame.transform.rotate(surface, -90)
    surface = pygame.transform.flip(surface, True, False)
    screen.blit(surface, (0, 0))

    dateFont = pygame.font.Font(None, 50)
    timeFont = pygame.font.Font(None, 80)
    Time = datetime.datetime.now()
    date = dateFont.render(Time.strftime("%A, %d %B %Y"), True, (255, 255, 255))
    Tim = timeFont.render(Time.strftime("%H:%M:%S"), True, (255, 255, 255))
    screen.blit(date, (50, 460))
    screen.blit(Tim, (50, 90))

def promptScreen():
    global prompt, partialPrompt, steveReply, wakeWord
    promptFont = pygame.font.Font(None, 45)
    if prompt == "" and partialPrompt != prompt:
        promptText = partialPrompt
    else:
        promptText = prompt
        if steveReply == "" and prompt != "":
            thread = threading.Thread(target=reply, daemon=True)
            thread.start()
            
    promptText = "Lucca: S" + promptText[1:]
    promptTextRender = promptFont.render(promptText.replace(wakeWord.title(),f"{wakeWord.title()},"), True, (255, 255, 255))

    words = f"{wakeWord.title()}: {steveReply}".split()
    Reply = ""
    y = 330
    for word in words:
        if len(Reply) + len(word) + 1 > 45:
            if "]" in Reply or "[" in Reply or '", ' in Reply: 
                Reply = "Steve: ..."
                y = 330
            steveReplyRender = promptFont.render(Reply, True, (255, 255, 255))
            screen.blit(steveReplyRender, (50, y))
            y += 60
            Reply = word
        else:
            Reply += (" " if Reply else "") + word
    if "]" in Reply or "[" in Reply or '", ' in Reply: 
        Reply = "Steve: ..."
        y = 330

    steveReplyRender = promptFont.render(Reply, True, (255, 255, 255))
    screen.blit(steveReplyRender, (50, y))
    screen.blit(promptTextRender, (50, 240))

def listenForWakeWord():
    global wakeWordDetected, prompt, wakeWord
    global running, index, partialPrompt, coverEars

    final = ""
    partial = ""

    while running:
        try:
            if platform.system() != "Darwin":
                inter = sd.RawInputStream(
                device=index,
                samplerate=48000,
                blocksize=2048,
                dtype="int16",
                channels=1,
                callback=callback
            )
            else:
                inter = sd.RawInputStream(
                    device=index,
                    samplerate=16000,
                    blocksize=8000,
                    dtype="int16",
                    channels=1,
                    callback=callback2
                )
            with inter:
                while running:
                    if coverEars:
                        break
                    data = q.get()
                    if recognizer.AcceptWaveform(data):
                        final = json.loads(recognizer.Result())["text"]
                        if wakeWord in final:
                            splitFinal = final.split(
                                wakeWord, 1
                            )[1]
                            prompt = wakeWord + splitFinal
                            final = ""
                            partialPrompt = ""
                    else:
                        partial = json.loads(recognizer.PartialResult())["partial"]
                        if wakeWord in partial:
                            prompt = ""
                            wakeWordDetected = True
                            splitPartial = partial.split(wakeWord, 1)[1]
                            partialPrompt = wakeWord + splitPartial
        except Exception as e:
            print(e)

                        
thread = threading.Thread(target=listenForWakeWord, daemon=True)
thread.start()

updateCheck = 0
screenOn = True

while running:
    pygame.mouse.set_visible(False)
    updateButton = pygame.Rect(950, 526, 50, 50)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and updateAvailable:
            if updateButton.collidepoint(event.pos):
                subprocess.run("echo 'steve' | sudo -S reboot",shell=True)
        elif event.type == pygame.FINGERDOWN and updateAvailable:
            x = event.x * 800
            y = event.y * 480
            if updateButton.collidepoint(x, y):
                subprocess.run("echo 'steve' | sudo -S reboot",shell=True)

    screen.fill((0, 0, 0))

    if display != "Sleep" and platform.system() != "Darwin" and screenOn == False:
        subprocess.run(["wlr-randr", "--output", "DSI-1", "--on"])
        screenOn = True

    if display == "Home":
        homeScreen()
    elif display == "buzz":
        promptScreen()
    elif display == "Sleep" and platform.system() != "Darwin" and screenOn:
        subprocess.run(["wlr-randr", "--output", "DSI-1", "--off"])
        screenOn = False
    elif "Alarm" in display:
        font = pygame.font.SysFont(None, 50)
        text = font.render(display.split(":")[1], True, (255, 255, 255))
        text_rect = text.get_rect(center=(800 // 2, 480 // 2))
        screen.blit(text, text_rect)
    if wakeWordDetected:
        display = "buzz"
    elif display != "Sleep" and "Alarm" not in display:
        display = "Home"

    connected = False
    if updateCheck%(60*60*5) == 0:
        try:
            response = requests.get("https://www.alfeh.uk/updateDates.txt", timeout=5)
            response.raise_for_status()
            if response.status_code == 200:
                connected = True
        except:
            pass
        if connected:
            try:
                updateFile = os.path.dirname(os.path.abspath(__file__))+"/updateDates.txt"
                updateREAD = open(updateFile, "r").read()
                if response.text[0:-1] != updateREAD:
                    updateAvailable = True
                else:
                    updateAvailable = False
            except:
                pass
    updateCheck += 1

    if display != "Sleep" and updateAvailable:
        pygame.draw.rect(screen, (255, 255, 255), updateButton)
        text = pygame.font.Font(None, 40).render("!", True, (0, 0, 0))
        text_rect = text.get_rect(center=updateButton.center)
        screen.blit(text, text_rect)

    #Auto update
    Time = datetime.datetime.now()
    if Time.strftime("%H:%M:%S") == "04:20:00" and updateAvailable:
        subprocess.run("echo 'steve' | sudo -S reboot",shell=True)

    checkAlarms()

    pygame.display.flip()
    clock.tick(60)

cap.release()
pygame.quit()