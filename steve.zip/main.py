import subprocess
import sys
import os
import pygame
import cv2
import datetime
import os
import threading
from vosk import Model, KaldiRecognizer
import sounddevice as sd
import queue
import json
import random
import platform

q = queue.Queue()
def callback(indata, frames, time, status):
    q.put(bytes(indata))
model = Model(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/vosk-model-small-en-us-0.15")
recognizer = KaldiRecognizer(model, 16000)
index = 1 if platform.system() != "Darwin" else 0

wakeWordDetected = False
prompt = ""
wakeWord = "steve"

pygame.init()
screen = pygame.display.set_mode((800, 480))
pygame.display.set_caption("Video")
running = True
clock = pygame.time.Clock()

display = "Home"

cap = cv2.VideoCapture(os.path.dirname(os.path.abspath(__file__))+"/Sample background.mp4")

def homeScreen():
    #RENDER BACKGROUND FIRST!!!!
    ret, frame = cap.read()
    if not ret:
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        ret, frame = cap.read()
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame = cv2.resize(frame, (800, 480))
    surface = pygame.surfarray.make_surface(frame)
    surface = pygame.transform.rotate(surface, -90)
    surface = pygame.transform.flip(surface, True, False)
    screen.blit(surface, (0, 0))

    #Date & Time
    dateFont = pygame.font.Font(None, 50)
    timeFont = pygame.font.Font(None, 80)
    time = datetime.datetime.now()
    date = dateFont.render(time.strftime("%A, %d %B %Y"), True, (255, 255, 255))
    time = timeFont.render(time.strftime("%H:%M:%S"), True, (255, 255, 255))
    screen.blit(date, (50, 360))
    screen.blit(time, (50, 70))

def listenForWakeWord():
    global wakeWordDetected, prompt, wakeWord, running, index, partialPrompt
    final, partial = "", ""
    with sd.RawInputStream(
    device=index,
    samplerate=16000,
    blocksize=8000,
    dtype="int16",
    channels=1,
    callback=callback
    ):
        while running:
            print(1)
            data = q.get()
            if recognizer.AcceptWaveform(data):
                final = json.loads(recognizer.Result())["text"]
                if wakeWord in final:
                    splitFinal = final.split(wakeWord)[1]
                    prompt = wakeWord+splitFinal
                    final = ""
            else:
                partial = json.loads(recognizer.PartialResult())["partial"]
                if wakeWord in partial:
                    wakeWordDetected = True
                    splitPartial = partial.split(wakeWord)[1]
                    partialPrompt = wakeWord+splitPartial
            print(f"FINAL: {final} PARTIAL: {partial} PROMPT: {prompt}",end="\n\n")

thread = threading.Thread(target=listenForWakeWord, daemon=True)
thread.start()

def reply():
    global wakeWordDetected, prompt
    while running:
        if not wakeWordDetected: continue
        prompt = prompt[len(wakeWord):]
        break #PASTE CODE IN HERE!!

thread = threading.Thread(target=reply, daemon=True)
thread.start()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill((0, 0, 0))

    if display == "Home":
        homeScreen()
    elif display == "buzz":
        screen.fill((0, 255, 0))

    if wakeWordDetected:
        display = "buzz"
    else:
        display = "Home"
    
    pygame.display.flip()

    clock.tick(30)

cap.release()
pygame.quit()