import os
import sys
import subprocess


# ============================================================
# INSTALL DEPENDENCIES
# ============================================================

def install_dependencies():
    print()
    print("========================================")
    print("     CHECKING STEVE DEPENDENCIES")
    print("========================================")
    print()

    # System packages
    print("Installing system audio dependencies...")

    subprocess.run(
        [
            "sudo",
            "apt-get",
            "update"
        ],
        check=True
    )

    subprocess.run(
        [
            "sudo",
            "apt-get",
            "install",
            "-y",
            "libportaudio2",
            "libportaudiocpp0",
            "portaudio19-dev",
            "libasound-dev",
            "libsndfile1-dev"
        ],
        check=True
    )

    # Python packages
    print()
    print("Installing Python dependencies...")

    subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--break-system-packages",
            "--upgrade",
            "pip"
        ],
        check=True
    )

    subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--break-system-packages",
            "elevenlabs[pyaudio]"
        ],
        check=True
    )

    print()
    print("Dependencies installed.")
    print()


# ============================================================
# INSTALL EVERYTHING BEFORE IMPORTING ELEVENLABS
# ============================================================

install_dependencies()


# ============================================================
# ELEVENLABS IMPORTS
# ============================================================

from elevenlabs.client import ElevenLabs
from elevenlabs.conversational_ai.conversation import Conversation
from elevenlabs.conversational_ai.default_audio_interface import (
    DefaultAudioInterface
)


# ============================================================
# CONFIG
# ============================================================

AGENT_ID = "agent_9101m0t53pkcf5r9pse8ptq8p3rx"

API_KEY = "sk_47e85c08567eb9093e9ae4ed448f396e89f1355cd2d97846"


# ============================================================
# CHECK API KEY
# ============================================================

if API_KEY == "PASTE_YOUR_ELEVENLABS_API_KEY_HERE":
    print()
    print("ERROR: You haven't entered your ElevenLabs API key.")
    print()
    print("Open this file and change:")
    print()
    print('API_KEY = "PASTE_YOUR_ELEVENLABS_API_KEY_HERE"')
    print()
    print("to your actual ElevenLabs API key.")
    sys.exit(1)


# ============================================================
# START
# ============================================================

print()
print("========================================")
print("          STEVE VOICE ASSISTANT")
print("========================================")
print()

print("Agent ID:", AGENT_ID)
print("Connecting to ElevenLabs...")
print()


# ============================================================
# ELEVENLABS CLIENT
# ============================================================

elevenlabs = ElevenLabs(
    api_key=API_KEY
)


# ============================================================
# CALLBACKS
# ============================================================

def agent_response(response):
    print()
    print("Steve:", response)


def user_transcript(transcript):
    print()
    print("You:", transcript)


def agent_correction(original, corrected):
    print()
    print(
        "Steve correction:",
        original,
        "->",
        corrected
    )


# ============================================================
# CONVERSATION
# ============================================================

conversation = Conversation(
    elevenlabs,
    AGENT_ID,

    requires_auth=True,

    audio_interface=DefaultAudioInterface(),

    callback_agent_response=agent_response,

    callback_agent_response_correction=agent_correction,

    callback_user_transcript=user_transcript
)


# ============================================================
# SHUTDOWN
# ============================================================

def shutdown(signal_number=None, frame=None):

    print()
    print("Stopping Steve...")

    try:
        conversation.end_session()
    except Exception:
        pass

    print("Steve stopped.")

    sys.exit(0)


import signal

signal.signal(
    signal.SIGINT,
    shutdown
)

signal.signal(
    signal.SIGTERM,
    shutdown
)


# ============================================================
# RUN
# ============================================================

try:

    print("----------------------------------------")
    print("Steve is listening.")
    print("Speak into the microphone.")
    print("Press CTRL+C to stop.")
    print("----------------------------------------")
    print()

    conversation.start_session()

    conversation_id = conversation.wait_for_session_end()

    print()
    print("Conversation ended.")
    print("Conversation ID:", conversation_id)

except KeyboardInterrupt:

    shutdown()

except Exception as e:

    print()
    print("========================================")
    print("ERROR")
    print("========================================")
    print()

    print(type(e).__name__)
    print(e)

    print()

    sys.exit(1)