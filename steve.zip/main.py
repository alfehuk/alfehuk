import sounddevice as sd

for i, d in enumerate(sd.query_devices()):
    if "SF-558" in d["name"]:
        print(f"Device {i}: {d['name']}")
        print("Default sample rate:", d["default_samplerate"])

        for rate in [16000, 32000, 44100, 48000]:
            try:
                sd.check_input_settings(
                    device=i,
                    samplerate=rate,
                    channels=1,
                    dtype="int16"
                )
                print(f"{rate} Hz: supported")
            except Exception as e:
                print(f"{rate} Hz: not supported ({e})")