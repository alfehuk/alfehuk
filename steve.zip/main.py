# IMPORTS
import subprocess, os, pygame, time, datetime
import os, threading
from vosk import Model, KaldiRecognizer
import queue, requests
from elevenlabs.client import ElevenLabs
from elevenlabs.conversational_ai.conversation import ConversationInitiationData

#IMPORT FILED FUNCTIONS/VARIABLES
import globalVariables, updating
import animations
from screens import homeScreen, promptScreen, alarmScreen
from alarmHandling import alarmData, checkAlarms, alarmSound, deleteRebootAlarms
from audioHandling import listenForWakeWord
from aLittleShow import startShow
import buttons

#BIG UPDATES
if not os.path.exists(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/vosk-model-en-us-0.22"):
    updating.updateVosk()

#PYGAME SETUP
pygame.init()
pygame.mixer.quit()
globalVariables.screen = pygame.display.set_mode((1024, 600))
pygame.display.set_caption("Steve")
pygame.mouse.set_visible(False)
clock = pygame.time.Clock()

#VOICE SETUP
globalVariables.q = queue.Queue()
globalVariables.model = Model(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/vosk-model-en-us-0.22")#"/vosk-model-en-gb-0.1")
globalVariables.recognizer = KaldiRecognizer(globalVariables.model, 16000)

#ELEVENLABS SETUP
globalVariables.elevenlabs = ElevenLabs(api_key="sk_47e85c08567eb9093e9ae4ed448f396e89f1355cd2d97846")
globalVariables.agentID = "agent_9101m0t53pkcf5r9pse8ptq8p3rx"
globalVariables.config = ConversationInitiationData(conversation_config_override={"conversation": {"text_only": True}})

#UPDATE CHECK SETUP
updateCheck = 0

#OTHER SETUP
globalVariables.fps = 1

#TURN OFF BACK LIGHTS FOR THE PI
if globalVariables.raspberryPi:
    subprocess.run(["sudo", "-S", "sh", "-c", "echo none > /sys/class/leds/PWR/trigger"], input="steve\n", text=True)
    subprocess.run(["sudo", "-S", "sh", "-c", "echo 0 > /sys/class/leds/PWR/brightness"], input="steve\n", text=True)
    subprocess.run(["sudo", "-S", "sh", "-c", "echo none > /sys/class/leds/ACT/trigger"], input="steve\n", text=True)
    subprocess.run(["sudo", "-S", "sh", "-c", "echo 0 > /sys/class/leds/ACT/brightness"], input="steve\n", text=True)
    time.sleep(2)

#LOAD ALARMS
globalVariables.allAlarms = [i for i in alarmData()]
deleteRebootAlarms()

if open(os.path.dirname(os.path.abspath(__file__))+"/theShow/amIShowing.txt","r").read() == "1":
    globalVariables.videoToPlay = True

#START THREADS
threading.Thread(target=listenForWakeWord, daemon=True, name="Wake word checker").start()
threading.Thread(target=checkAlarms, daemon=True, name="Alarm checker").start()

while globalVariables.running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            globalVariables.running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            buttons.pressed(event.pos[0],event.pos[1])
        elif event.type == pygame.FINGERDOWN:
            buttons.pressed(event.x * 1024, event.y * 600)

    globalVariables.screen.fill((0, 0, 0))

    if globalVariables.display == "Home":
        globalVariables.fps = 10
        globalVariables.homeScreenOpac = 255
    elif globalVariables.display == "buzz":
        globalVariables.fps = 60
        promptScreen()
    elif "Alarm" in globalVariables.display:
        alarmScreen()
        if not globalVariables.alarmGoing:
            alarmSound()
            globalVariables.alarmGoing = True

    if globalVariables.homeScreenOpac != 0:
        homeScreen(globalVariables.homeScreenOpac)
    
    if globalVariables.wakeWordDetected:
        globalVariables.display = "buzz"
        if globalVariables.homeTransition == 0 and globalVariables.homeScreenOpac == 255:
            threading.Thread(target=animations.fadeOutHomeScreen, daemon=True, name="Fade out home screen").start()
    elif "Alarm" not in globalVariables.display:
        globalVariables.display = "Home"

    if globalVariables.alarmGoing and "Alarm" not in globalVariables.display:
        globalVariables.alarmGoing = False
        try:pygame.mixer.quit()
        except: pass

    if updateCheck%(globalVariables.fps*60*60) == 0 and not globalVariables.updateAvailable:
        connected = False
        try:
            response = requests.get("https://www.alfeh.uk/updateDates.txt", timeout=5)
            response.raise_for_status()
            if response.status_code == 200:
                connected = True
        except:
            pass
        if connected:
            try:
                updateFile = os.path.dirname(os.path.abspath(__file__))+"/updateDates.txt"
                updateREAD = open(updateFile, "r").read()
                if response.text[0:-1] != updateREAD:
                    globalVariables.updateAvailable = True
                else:
                    globalVariables.updateAvailable = False
            except:
                pass
    updateCheck += 1

    if globalVariables.updateAvailable:
        pygame.draw.rect(globalVariables.screen, (255, 255, 255), buttons.updateButton, border_radius=5)
        text = buttons.alertButtonFont.render("!", True, (0, 0, 0))
        text_rect = text.get_rect(center=buttons.updateButton.center)
        globalVariables.screen.blit(text, text_rect)

    #AUTO UPDATE!
    Time = datetime.datetime.now()
    if Time.strftime("%H:%M:%S") == "04:20:00" and globalVariables.updateAvailable:
        subprocess.run("echo 'steve' | sudo -S reboot",shell=True)
    pygame.display.flip()
    clock.tick(globalVariables.fps)

pygame.quit()