import subprocess
import sys
import os
import pygame
import cv2
import datetime
import os
import threading
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),"packages"))
from speech_recognition import speech_recognition as sr
import random
import platform

recognizer = sr.Recognizer()
index = 1 if platform.system() != "Darwin" else 0
mic = sr.Microphone(device_index=index,sample_rate=48000,chunk_size=1024)
wakeWordDetected = False
prompt = ""
wakeWord = "steve"

pygame.init()
screen = pygame.display.set_mode((800, 480))
pygame.display.set_caption("Video")
running = True
clock = pygame.time.Clock()

display = "Home"

cap = cv2.VideoCapture(os.path.dirname(os.path.abspath(__file__))+"/Sample background.mp4")

def homeScreen():
    #RENDER BACKGROUND FIRST!!!!
    ret, frame = cap.read()
    if not ret:
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        ret, frame = cap.read()
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame = cv2.resize(frame, (800, 480))
    surface = pygame.surfarray.make_surface(frame)
    surface = pygame.transform.rotate(surface, -90)
    surface = pygame.transform.flip(surface, True, False)
    screen.blit(surface, (0, 0))

    #Date & Time
    dateFont = pygame.font.Font(None, 50)
    timeFont = pygame.font.Font(None, 80)
    time = datetime.datetime.now()
    date = dateFont.render(time.strftime("%A, %d %B %Y"), True, (255, 255, 255))
    time = timeFont.render(time.strftime("%H:%M:%S"), True, (255, 255, 255))
    screen.blit(date, (50, 360))
    screen.blit(time, (50, 70))

def listenForWakeWord():
    global wakeWordDetected, prompt, wakeWord
    while running:
        try:
            recognizer.adjust_for_ambient_noise(source,duration=2)
            with mic as source:
                audio = recognizer.listen(source,timeout=10, phrase_time_limit=10)
            text = recognizer.recognize_google(audio).lower()
            print(text)
            if wakeWord == text[0:len(wakeWord)]:
                wakeWordDetected = True
                prompt = text
                continue
            else:
                wakeWordDetected = False
        except:
            wakeWordDetected = False

thread = threading.Thread(target=listenForWakeWord, daemon=True)
thread.start()

def reply():
    global wakeWordDetected, prompt
    while running:
        if not wakeWordDetected: continue
        prompt = prompt[len(wakeWord):]
        break #PASTE CODE IN HERE!!

thread = threading.Thread(target=reply, daemon=True)
thread.start()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill((0, 0, 0))

    if display == "Home":
        homeScreen()
    elif display == "buzz":
        screen.fill((0, 255, 0))

    if wakeWordDetected:
        display = "buzz"
    else:
        display = "Home"
    
    pygame.display.flip()

    clock.tick(30)

cap.release()
pygame.quit()