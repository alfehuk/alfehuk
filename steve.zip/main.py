import subprocess
import sys
import os
import pygame
import cv2
import datetime
import os
import threading
from vosk import Model, KaldiRecognizer
import sounddevice as sd
import queue
import time
import json
import random
import platform
from elevenlabs.client import ElevenLabs
from elevenlabs.play import play
from elevenlabs.conversational_ai.conversation import (
    Conversation,
    ConversationInitiationData
)

q = queue.Queue()
def callback(indata, frames, time, status):
    q.put(bytes(indata))
model = Model(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/vosk-model-small-en-us-0.15")
recognizer = KaldiRecognizer(model, 16000)
index = 1 if platform.system() != "Darwin" else 0

APIKEY = "sk_47e85c08567eb9093e9ae4ed448f396e89f1355cd2d97846"

elevenlabs = ElevenLabs(
    api_key=APIKEY
)
agentID = "agent_9101m0t53pkcf5r9pse8ptq8p3rx"

wakeWordDetected = False
prompt = ""
partialPrompt = ""
steveReply = ""
wakeWord = "steve"

pygame.init()
screen = pygame.display.set_mode((800, 480))
pygame.display.set_caption("Video")
running = True
clock = pygame.time.Clock()

display = "Home"

cap = cv2.VideoCapture(os.path.dirname(os.path.abspath(__file__))+"/Sample background.mp4")

config = ConversationInitiationData(
    conversation_config_override={
        "conversation": {
            "text_only": True
        }
    }
)

def agentResponse(response):
    global steveReply
    steveReply = response
    print(steveReply)

sessionReady = False
def sessionStarted():
    global sessionReady
    sessionReady = True

def reply():
    global prompt, steveReply, wakeWordDetected, sessionReady, partialPrompt
    steveReply = "*thinking*"
    conversation = Conversation(
    client=elevenlabs,
    agent_id=agentID,
    requires_auth=True,
    config=config,
    callback_agent_response=agentResponse
    )
    conversation.start_session()
    Prompt = prompt[len(wakeWord):]

    while True:
        try:
            conversation.send_user_message(Prompt)
            break
        except RuntimeError as e:
            if "Session not started or websocket not connected" in str(e):
                time.sleep(0.1)
            else:
                raise

    while steveReply == "*thinking*":
        time.sleep(0.05)

    audio = elevenlabs.text_to_speech.convert(
    text=steveReply,
    voice_id="JBFqnCBsd6RMkjVDRZzb",
    model_id="eleven_v3",
    output_format="mp3_44100_128")
    play(audio)

    time.sleep(0.5)

    conversation.end_session()
    for _ in range(40):
        if partialPrompt != "":
            prompt, steveReply = "", ""
            return
        time.sleep(0.1)
    prompt, steveReply = "", "" #IMPORTANT
    wakeWordDetected = False

def homeScreen():
    #RENDER BACKGROUND FIRST!!!!
    ret, frame = cap.read()
    if not ret:
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        ret, frame = cap.read()
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame = cv2.resize(frame, (800, 480))
    surface = pygame.surfarray.make_surface(frame)
    surface = pygame.transform.rotate(surface, -90)
    surface = pygame.transform.flip(surface, True, False)
    screen.blit(surface, (0, 0))

    #Date & Time
    dateFont = pygame.font.Font(None, 50)
    timeFont = pygame.font.Font(None, 80)
    time = datetime.datetime.now()
    date = dateFont.render(time.strftime("%A, %d %B %Y"), True, (255, 255, 255))
    time = timeFont.render(time.strftime("%H:%M:%S"), True, (255, 255, 255))
    screen.blit(date, (50, 360))
    screen.blit(time, (50, 70))

def promptScreen():
    global prompt, partialPrompt, steveReply, wakeWord
    promptFont = pygame.font.Font(None, 45)
    if prompt == "" and partialPrompt != prompt:
        promptText = partialPrompt
    else:
        promptText = prompt
        if steveReply == "" and prompt != "":
            thread = threading.Thread(target=reply, daemon=True)
            thread.start()
            
    promptText = "Lucca: S" + promptText[1:]
    promptTextRender = promptFont.render(promptText.replace(wakeWord.title(),f"{wakeWord.title()},"), True, (255, 255, 255))
    Reply = f"{wakeWord.title()}: {steveReply}"
    words = Reply.split()
    Reply = ""
    y = 260
    for word in words:
        if len(Reply) + len(word) + 1 > 45:
            steveReplyRender = promptFont.render(Reply, True, (255, 255, 255))
            screen.blit(steveReplyRender, (50, y))
            y += 60
            Reply = word
        else:
            Reply += (" " if Reply else "") + word
    steveReplyRender = promptFont.render(Reply, True, (255, 255, 255))
    screen.blit(steveReplyRender, (50, y))
    screen.blit(promptTextRender, (50, 170))

def listenForWakeWord():
    global wakeWordDetected, prompt, wakeWord, running, index, partialPrompt
    final, partial = "", ""
    with sd.RawInputStream(
    device=index,
    samplerate=16000,
    blocksize=8000,
    dtype="int16",
    channels=1,
    callback=callback
    ):
        while running:
            data = q.get()
            if recognizer.AcceptWaveform(data):
                final = json.loads(recognizer.Result())["text"]
                if wakeWord in final:
                    splitFinal = final.split(wakeWord)[1]
                    prompt = wakeWord+splitFinal
                    final, partialPrompt = "", ""
            else:
                partial = json.loads(recognizer.PartialResult())["partial"]
                if wakeWord in partial:
                    prompt = ""
                    wakeWordDetected = True
                    splitPartial = partial.split(wakeWord)[1]
                    partialPrompt = wakeWord+splitPartial

thread = threading.Thread(target=listenForWakeWord, daemon=True)
thread.start()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill((0, 0, 0))

    if display == "Home":
        homeScreen()
    elif display == "buzz":
        promptScreen()
    if wakeWordDetected:
        display = "buzz"
    else:
        display = "Home"
    
    pygame.display.flip()

    clock.tick(30)

cap.release()
pygame.quit()