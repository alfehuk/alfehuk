from vosk import Model, KaldiRecognizer
import os, platform, queue, random, time, json, threading
import sounddevice as sd
import numpy as np
from scipy.signal import resample_poly

model = Model(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/vosk-model-en-gb-0.1")
recognizer = KaldiRecognizer(model, 16000)
q = queue.Queue()

partialPrompt = ""
prompt = ""

def find_mic():
    devices = sd.query_devices()
    for i, device in enumerate(devices):
        if "SF-558" in device["name"] and device["max_input_channels"] > 0:
            return i
    raise RuntimeError("SF-558 microphone not found")
if platform.system() != "Darwin":
    index = find_mic()
else:
    index = 0

def getLatestAudio():
    data = q.get()
    return data

def callback2(indata, frames, time_info, status):
    if status:print("Audio status:", status)
    try:
        q.put_nowait(bytes(indata))
    except queue.Full:
        print("Not putting data in that thing bud")
        print(random.randint(1,1000))

def callback(indata, frames, time_info, status):
    if status: print("Audio status:", status)
    try:
        q.put_nowait(bytes(indata))
    except queue.Full:
        print("Not putting data in that thing bud")
        print(random.randint(1,1000))


def listenForWakeWord():
    global prompt, partialPrompt, recognizer

    if platform.system() != "Darwin":
        samplerate = 48000
        blocksize = 4096
        callbackFN = callback
    else:
        samplerate = 16000
        blocksize = 4000
        callbackFN = callback2

    while True:
        try:
            inter = sd.RawInputStream(
                device=index,
                samplerate=samplerate,
                blocksize=blocksize,
                dtype="int16",
                channels=1,
                callback=callbackFN
            )

            with inter:
                while True:
                    data = getLatestAudio()
                    start = time.perf_counter()
                    if platform.system() != "Darwin":
                        audio_48k = np.frombuffer(data,dtype=np.int16)
                        audio_16k = resample_poly(audio_48k,16000,48000).astype(np.int16)
                        resample_time = time.perf_counter() - start
                        data = audio_16k.tobytes()
                    
                    start = time.perf_counter()

                    if recognizer.AcceptWaveform(data):
                        final = json.loads(recognizer.Result())["text"]
                        prompt = final
                    else:
                        partial = json.loads(recognizer.PartialResult())["partial"]
                        partialPrompt = partial
                    vosk_time = time.perf_counter() - start
                    if platform.system() != "Darwin":
                        if resample_time > 0.02 or vosk_time > 0.02:
                            print(
                                f"Resample: {resample_time:.3f}s | "
                                f"Vosk: {vosk_time:.3f}s | "
                                f"Queue: {q.qsize()}"
                            )

        except Exception as e:
            print("Audio stream error:", e)
            recognizer = KaldiRecognizer(model, 16000)
            time.sleep(1)

thread = threading.Thread(target=listenForWakeWord, daemon=True, name="Wake word checker")
thread.start()

while True:
    print(f"'{prompt}', '{partialPrompt}'")