import globalVariables, time

def fadeOutHomeScreen():
    globalVariables.homeTransition = 1
    while globalVariables.homeScreenOpac != 0:
        if globalVariables.homeScreenOpac > 0:
            globalVariables.homeScreenOpac -= 11
        if globalVariables.homeScreenOpac < 0:
            globalVariables.homeScreenOpac = 0
        time.sleep(0.01)
    globalVariables.homeTransition = 0

def fadeInHomeScreen():
    globalVariables.coverEars = True
    globalVariables.homeTransition = 2
    while globalVariables.homeScreenOpac != 255:
        if globalVariables.homeScreenOpac < 255:
            globalVariables.homeScreenOpac += 11
        if globalVariables.homeScreenOpac > 255:
            globalVariables.homeScreenOpac = 255
        time.sleep(0.01)
    globalVariables.wakeWordDetected = False
    globalVariables.homeTransition = 0
    globalVariables.coverEars = False