import subprocess, datetime, random, os

wakeWord = "steve"

def speak(text):
    for updated in text.split(". "):
        subprocess.run([
            "/usr/bin/python3",
            "-m",
            "piper",
            "--model",
            f"{os.path.dirname(os.path.abspath(__file__))}/en_GB-northern_english_male-medium.onnx",
            "--output_file",
            f"{os.path.dirname(os.path.abspath(__file__))}/response.wav"
        ], input=updated.encode())
        subprocess.run([
                "afplay",
                f"{os.path.dirname(os.path.abspath(__file__))}/response.wav"
        ])

prompt = f"{wakeWord} set a timer for 15 minutes"[len(wakeWord)+1:]

#Time
timePrompts = [
    "what time is it",
    "what's the time",
    "what is the time",
    "tell me the time",
    "can you tell me the time",
    "do you know the time",
    "what's the current time",
    "what time is it right now",
    "what's the time right now",
    "what time is it now",
    "tell me what time it is",
    "give me the time"
]

if prompt in timePrompts:
    now = datetime.datetime.now()
    speak(now.strftime(random.choice(["It's", "The time is"])+" %I:%M %p"))

elif "set an alarm for" in prompt: #MAKE THIS FUNCTIONAL
    forWhen = prompt.split("set an alarm for ")[1].replace("o'clock","").split(" ")[0]
    hours, minutes = 0, 0
    if ":" in forWhen:
        hours, minutes = forWhen.split(":")[0], forWhen.split(":")[1]
    else:
        hours = forWhen
    if minutes == 0:
        end = "o'clock"
    else:
        end = minutes
    speak(f"Set an alarm for {hours} {end}")

elif "set a timer for" in prompt:
    forWhen = prompt.split("set a timer for ")[1]
    if forWhen.split(" ")[1] == "minutes":
        speak(f"{forWhen.split(' ')[0]} minutes, counting down")
    else:
        speak(f"{forWhen[0]} hours")