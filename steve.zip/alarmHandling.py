import globalVariables, json, datetime, subprocess, time, pygame, os
from datetime import timedelta

def alarmData():
    while True:
        try:
            with open(globalVariables.alarmDir, "r") as file:
                data = json.load(file)
                break
        except:
            with open(globalVariables.alarmDir, "w") as file:
                file.write("[]")
    return data

def dumpAlarms(data):
    with open(globalVariables.alarmDir, "w") as file:
        json.dump(data, file, indent=4)

def deleteAlarm(alarm):
    globalVariables.allAlarms.remove(alarm)
    data = alarmData()
    data.remove(alarm)
    dumpAlarms(data)

def checkAlarms():
    while globalVariables.running:
        for alarm in globalVariables.allAlarms:
            if alarm["time"] == datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"):
                globalVariables.display = "Alarm:"+alarm["name"]
                deleteAlarm(alarm)
                if alarm["name"] == "Reboot" and globalVariables.raspberryPi:
                    subprocess.run("echo 'steve' | sudo -S reboot",shell=True)
        time.sleep(0.4)

def addRawAlarm(name, time):
    Data = {"name": name,"time": str(time)}
    data = alarmData()
    globalVariables.allAlarms.append(Data)
    data.append(Data)
    dumpAlarms(data)

def addAlarm(inp):
    inp = json.loads(inp)
    if inp[0] == "Timer":
        timerTime = inp[2].split(" ")[1].split(":")
        inp[2] = datetime.datetime.now() + timedelta(
            hours=int(timerTime[0]),
            minutes=int(timerTime[1]),
            seconds=int(timerTime[2])
        ) + timedelta(
            days=(
                datetime.datetime.strptime(
                    inp[2].split(" ")[0],
                    "%d/%m/%Y"
                ) - datetime.datetime.strptime(
                    str(datetime.datetime.now()).split(" ")[0],
                    "%Y-%m-%d")
            ).days
        )
        inp[2] = inp[2].strftime("%d/%m/%Y %H:%M:%S")
    if inp[1] == "":
        inp[1] = inp[0]
    addRawAlarm(inp[1], inp[2])

def alarmSound():
    pygame.mixer.music.load(os.path.dirname(os.path.abspath(__file__))+"/Mama y papa.mp3")
    pygame.mixer.music.play(loops=-1)

def deleteRebootAlarms():
    for alarm in globalVariables.allAlarms:
        if alarm["name"] == "Reboot":
            deleteAlarm(alarm)

def setRebootAlarm():
    deleteRebootAlarms()
    toCompare = []
    now = datetime.datetime.now()
    for alarm in globalVariables.allAlarms:
        then = datetime.datetime.strptime(alarm["time"], "%d/%m/%Y %H:%M:%S")
        difference = (then - now).total_seconds()
        if difference > 0:
            toCompare.append([alarm, difference])
    addRawAlarm("Reboot", now+datetime.timedelta(seconds=min([i[1] for i in toCompare])-(5*60)))