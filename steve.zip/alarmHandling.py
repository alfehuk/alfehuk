import globalVariables, json, datetime, subprocess, time, pygame, os
from datetime import timedelta

def alarmData():
    while True:
        try:
            with open(globalVariables.alarmDir, "r") as file:
                data = json.load(file)
                break
        except:
            with open(globalVariables.alarmDir, "w") as file:
                file.write("[]")
    return data

def dumpAlarms(data):
    with open(globalVariables.alarmDir, "w") as file:
        json.dump(data, file, indent=4)

def grabAlarms(parameters):
    return f"{globalVariables.allAlarms}"

def deleteAlarm(alarm):
    try:alarm = alarm["alarm"]
    except:pass
    globalVariables.allAlarms.remove(alarm)
    data = alarmData()
    data.remove(alarm)
    dumpAlarms(data)

def checkAlarms():
    while globalVariables.running:
        for alarm in globalVariables.allAlarms:
            if alarm["time"] == datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"):
                globalVariables.display = "Alarm:"+alarm["name"]
                deleteAlarm(alarm)
                if alarm["name"] == "Reboot" and globalVariables.raspberryPi:
                    subprocess.run("echo 'steve' | sudo -S reboot",shell=True)
        time.sleep(0.4)

def addRawAlarm(name, theTime):
    theTime = str(theTime).replace("-","/")
    Data = {"name": name,"time": theTime}
    data = alarmData()
    globalVariables.allAlarms.append(Data)
    data.append(Data)
    dumpAlarms(data)

def getTime(parameters):
    currentTime = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    return currentTime

def addAlarm(parameters):
    name = parameters.get("name")
    theTime = parameters.get("theTime")
    timerTime = theTime.split(":")
    alarmTime = datetime.datetime.now() + timedelta(
            hours=int(timerTime[0]),
            minutes=int(timerTime[1]),
            seconds=int(timerTime[2])
        )
    alarmTime = alarmTime.strftime("%d/%m/%Y %H:%M:%S")

    addRawAlarm(name, alarmTime)

def alarmSound():
    pygame.mixer.init()
    sound = pygame.mixer.Sound(os.path.dirname(os.path.abspath(__file__))+"/Mama y papa.mp3")
    sound.play(loops=-1)
    sound.set_volume(1)
    

def deleteRebootAlarms():
    for alarm in globalVariables.allAlarms:
        if alarm["name"] == "Reboot":
            deleteAlarm(alarm)

def setRebootAlarm():
    deleteRebootAlarms()
    toCompare = [[{},60*60*8+5*60]]
    now = datetime.datetime.now()
    for alarm in globalVariables.allAlarms:
        then = datetime.datetime.strptime(alarm["time"], "%d/%m/%Y %H:%M:%S")
        difference = (then - now).total_seconds()
        if difference > 0:
            toCompare.append([alarm, difference])
    addRawAlarm("Reboot", (now+datetime.timedelta(seconds=min([i[1] for i in toCompare])-(5*60))).strftime("%d/%m/%Y %H:%M:%S"))