import globalVariables, json, datetime, subprocess, time
from datetime import timedelta

def alarmData():
    while True:
        try:
            with open(globalVariables.alarmDir, "r") as file:
                data = json.load(file)
                break
        except:
            with open(globalVariables.alarmDir, "w") as file:
                file.write("[]")
    return data

def dumpAlarms(data):
    with open(globalVariables.alarmDir, "w") as file:
        json.dump(data, file, indent=4)

def checkAlarms():
    while globalVariables.running:
        for alarm in globalVariables.allAlarms:
            if alarm["time"] == datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"):
                data = alarmData()
                globalVariables.display = "Alarm:"+alarm["name"]
                data.remove(alarm)
                globalVariables.allAlarms.remove(alarm)
                dumpAlarms(data)
                if alarm["name"] == "Reboot" and globalVariables.raspberryPi:
                    subprocess.run("echo 'steve' | sudo -S reboot",shell=True)
        time.sleep(0.4)

def addAlarm(inp):
    inp = json.loads(inp)
    if inp[0] == "Timer":
        timerTime = inp[2].split(" ")[1].split(":")
        inp[2] = datetime.datetime.now() + timedelta(
            hours=int(timerTime[0]),
            minutes=int(timerTime[1]),
            seconds=int(timerTime[2])
        ) + timedelta(
            days=(
                datetime.datetime.strptime(
                    inp[2].split(" ")[0],
                    "%d/%m/%Y"
                ) - datetime.datetime.strptime(
                    str(datetime.datetime.now()).split(" ")[0],
                    "%Y-%m-%d")
            ).days
        )
        inp[2] = inp[2].strftime("%d/%m/%Y %H:%M:%S")
    if inp[1] == "":
        inp[1] = inp[0]
    Data = {"name": inp[1],"time": inp[2]}
    data = alarmData()
    globalVariables.allAlarms.append(Data)
    data.append(Data)
    dumpAlarms(data)

def alarmSound():
    while "Alarm" in globalVariables.display:
        pass