import subprocess, sys, time, os
print("Checking for updates...")
loadingScreen = subprocess.Popen([sys.executable, "/home/steve/Desktop/lucca/loadingScreen.py"])
try:
    time.sleep(30)
    process = subprocess.Popen([sys.executable, "/home/steve/Desktop/lucca/connect to wifi.py"])
    process.wait()
    os.system('wmctrl -a "Updating"')
    time.sleep(10)
    subprocess.run([sys.executable, "/home/steve/Desktop/lucca/update.py"])
    time.sleep(1)
    subprocess.run([sys.executable, "/home/steve/Desktop/lucca/steve/main.py"])
finally:
    loadingScreen.terminate()
    loadingScreen.wait()