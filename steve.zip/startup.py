import subprocess, sys, time
print("Checking for updates...")
loadingScreen = subprocess.Popen([sys.executable, "/home/steve/Desktop/lucca/loadingScreen.py"])
try:
    time.sleep(20)
    process = subprocess.Popen([sys.executable, "/home/steve/Desktop/lucca/connect to wifi.py"])
    process.wait()
    time.sleep(1)
    subprocess.run([sys.executable, "/home/steve/Desktop/lucca/update.py"])
    time.sleep(1)
    subprocess.run([sys.executable, "/home/steve/Desktop/lucca/steve/main.py"])
finally:
    loadingScreen.terminate()
    loadingScreen.wait()