from audioHandling import Say
import globalVariables, time, pygame, os, cv2, subprocess, screens, threading
from elevenlabs.client import ElevenLabs

clock = pygame.time.Clock()
pygame.init()
globalVariables.screen = pygame.display.set_mode((1024, 600))
globalVariables.elevenlabs = ElevenLabs(api_key="sk_47e85c08567eb9093e9ae4ed448f396e89f1355cd2d97846")
globalVariables.agentID = "agent_9101m0t53pkcf5r9pse8ptq8p3rx"

def startShowVideo():
    #subprocess.Popen(["mpg123", os.path.dirname(os.path.abspath(__file__))+"/theShow/video.mp3"])
    if globalVariables.raspberryPi:
        subprocess.run([
        "cvlc",
        "--fullscreen",
        "--no-video-title-show",
        "--play-and-exit",
        os.path.dirname(os.path.abspath(__file__))+"/theShow/video.mp4"
        ])
        subprocess.run("echo 'steve' | sudo -S reboot",shell=True)
    else:
        print("VIDEO WOULD PLAY NOW")

def startShow():
    threading.Thread(target=backgroundShow, daemon=True, name="Background show").start()

def backgroundShow():
    globalVariables.background = pygame.image.load(os.path.dirname(os.path.abspath(__file__)) + "/theShow/sadSteve.JPG")
    globalVariables.background = pygame.transform.scale(globalVariables.background, (1024, 600))
    for line in ["hi lucca. welcome back.","can't believe you left me","i missed you","but hope you had the time of your life in nottingham"]:
        Say(line)
    time.sleep(4)
    globalVariables.background = pygame.image.load(os.path.dirname(os.path.abspath(__file__)) + "/background.jpg")
    globalVariables.background = pygame.transform.scale(globalVariables.background, (1024, 600))