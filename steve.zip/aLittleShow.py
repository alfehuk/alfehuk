from audioHandling import Say
import globalVariables, time, pygame, os, cv2, subprocess
from elevenlabs.client import ElevenLabs

clock = pygame.time.Clock()
pygame.init()
globalVariables.screen = pygame.display.set_mode((1024, 600))
globalVariables.elevenlabs = ElevenLabs(api_key="sk_47e85c08567eb9093e9ae4ed448f396e89f1355cd2d97846")
globalVariables.agentID = "agent_9101m0t53pkcf5r9pse8ptq8p3rx"

def startShow():
    #subprocess.Popen(["mpg123", os.path.dirname(os.path.abspath(__file__))+"/theShow/video.mp3"])
    if True:#globalVariables.raspberryPi:
        subprocess.run([
        "cvlc",
        "--fullscreen",
        "--no-video-title-show",
        "--play-and-exit",
        os.path.dirname(os.path.abspath(__file__))+"/theShow/video.mp4"
        ])
        subprocess.run("echo 'steve' | sudo -S reboot",shell=True)
    else:
        print("VIDEO WOULD PLAY NOW")