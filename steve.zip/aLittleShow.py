from audioHandling import Say
import globalVariables, time, pygame, os, cv2
from elevenlabs.client import ElevenLabs

clock = pygame.time.Clock()
pygame.init()
globalVariables.screen = pygame.display.set_mode((1024, 600))
globalVariables.elevenlabs = ElevenLabs(api_key="sk_47e85c08567eb9093e9ae4ed448f396e89f1355cd2d97846")
globalVariables.agentID = "agent_9101m0t53pkcf5r9pse8ptq8p3rx"

def start():
    pygame.mixer.init()
    if True:    
        while globalVariables.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    globalVariables.running = False
            globalVariables.screen.fill((0, 0, 0))
            pygame.display.flip()
            break
        pygame.mixer.music.load(os.path.dirname(os.path.abspath(__file__))+"/theShow/summon.mp3")
        pygame.mixer.music.play(loops=2)
        time.sleep(10)
        globalVariables.coverEars = True
        for toSay in ["Oi?", "Lucca?", "Where are you?","","Am I really that boring?", "", "", "I have something to show you."]:
            Say(toSay)
        time.sleep(2)
    cap = cv2.VideoCapture(os.path.dirname(os.path.abspath(__file__))+"/theShow/video.mp4")
    while globalVariables.running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                globalVariables.running = False
        ret, frame = cap.read()
        if not ret:
            pygame.mixer.quit()
            break
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame = cv2.resize(frame, (1024, 600))
        surface = pygame.surfarray.make_surface(frame)
        surface = pygame.transform.rotate(surface, -90)
        surface = pygame.transform.flip(surface, True, False)
        if int(cap.get(cv2.CAP_PROP_POS_FRAMES)) == 1:
            pygame.mixer.music.load(os.path.dirname(os.path.abspath(__file__))+"/theShow/video.mp3")
            pygame.mixer.music.play()
        globalVariables.screen.blit(surface, (0, 0))
        pygame.display.flip()
        clock.tick(60)
    time.sleep(2)